// HunterAudio.js — Audio-only drill (L0; no SRS changes)

(function () {
  'use strict';

// --- TTS helpers (match HanziList / HunterCards behavior) ---
function adSpeakChar(ch){
  try {
    if (typeof window.speakChar === 'function') return window.speakChar(ch);
  } catch {}

  // Fallback: Web Speech for a single char
  if ('speechSynthesis' in window){
    try { speechSynthesis.cancel(); } catch {}
    const u = new SpeechSynthesisUtterance(String(ch || ''));
    try {
      u.lang = (window.settings?.lang || 'zh-CN');
      // if you have a dedicated charRate in your app, honor it; else fall back to sentenceRate or 1
      u.rate = Number(window.settings?.charRate) || Number(window.settings?.sentenceRate) || 1;
    } catch {}
    try { speechSynthesis.speak(u); } catch {}
  }
}

function adSpeakSentence(s){
  if (!s) return;
  try {
    if (typeof window.speakSentence === 'function') return window.speakSentence(s);
  } catch {}

  // Fallback: Web Speech for sentences
  if ('speechSynthesis' in window){
    try { speechSynthesis.cancel(); } catch {}
    const u = new SpeechSynthesisUtterance(String(s));
    try {
      u.lang = (window.settings?.lang || 'zh-CN');
      u.rate = Number(window.settings?.sentenceRate) || 1; // <-- speed from your hamburger menu
    } catch {}
    try { speechSynthesis.speak(u); } catch {}
  }
}


  /* =========================
   * Env flags
   * ========================= */
  // Treat "mobile" as UA match OR touch device with moderate screen width
  const IS_MOBILE = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent || '') ||
                    (('ontouchstart' in window) && (window.screen?.width || 0) <= 1024);

  /* =========================
   * Range utilities (robust to empty strings)
   * ========================= */

  function getCurrentRange() {
    const total = (Array.isArray(window.chars) ? window.chars.length : 1);
    const r = (window.settings && window.settings.range) ? window.settings.range : {};
    const min = Math.max(1, Number(r.min) || 1);
    const max = Math.max(min, Number(r.max) || total);
    return { min, max, total };
  }

  function rangeText() {
    const { min, max, total } = getCurrentRange();
    return `${min}–${max} of ${total}`;
  }

  /* =========================
   * Pool builders
   * ========================= */

  function buildL0SeenDueTomorrowPool(maxCount) {
    const col   = (typeof getActiveCollection === 'function') ? getActiveCollection() : null;
    const items = col?.items || {};
    const total = (Array.isArray(window.chars) ? window.chars.length : 0);

    const now = new Date();
    const startTomorrow = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1, 0, 0, 0, 0).getTime();
    const endTomorrow   = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 2, 0, 0, 0, 0).getTime() - 1;

    const { min: a, max: b } = getCurrentRange();

    const pool = [];
    for (let rank = a; rank <= Math.min(b, total); rank++) {
      const ch  = window.chars[rank - 1];
      const key = (typeof itemKeyForChar === 'function') ? itemKeyForChar(ch) : ch;
      const it  = items[key];
      if (!it) continue;

      const level = Number(it.level) || 0;
      const views = Number(it.views) || 0;
      const r     = Number(it.r) || 0;
      const w     = Number(it.w) || 0;
      const seen  = (views > 0) || ((r + w) > 0);
      const next  = Number(it.PrTS ?? it.next) || 0;

      if (level === 0 && seen && next >= startTomorrow && next <= endTomorrow) {
        pool.push({ ch, rank, it });
      }
    }

    if (typeof shuffleInPlace === 'function') shuffleInPlace(pool);
    return pool.slice(0, Math.max(0, maxCount || pool.length));
  }

  function buildL0AnsweredPool(maxCount) {
    const col   = (typeof getActiveCollection === 'function') ? getActiveCollection() : null;
    const items = col?.items || {};
    const total = (Array.isArray(window.chars) ? window.chars.length : 0);
    const { min: a, max: b } = getCurrentRange();

    const pool = [];
    for (let rank = a; rank <= Math.min(b, total); rank++) {
      const ch  = window.chars[rank - 1];
      const key = (typeof itemKeyForChar === 'function') ? itemKeyForChar(ch) : ch;
      const it  = items[key];
      if (!it) continue;

      const level = Number(it.level) || 0;
      const r     = Number(it.r) || 0;
      const w     = Number(it.w) || 0;
      if (level === 0 && (r + w) > 0) pool.push({ ch, rank, it });
    }

    if (typeof shuffleInPlace === 'function') shuffleInPlace(pool);
    return pool.slice(0, Math.max(0, maxCount || pool.length));
  }

  /* =========================
   * Data lookups (mirror List/Card behavior)
   * ========================= */

  function pinyinForChar(ch) {
    try {
      const idx = window.pyIndex?.[ch];
      if (idx && idx[0] && (idx[0].py || idx[0].pinyin)) {
        return String(idx[0].py || idx[0].pinyin || '');
      }
    } catch {}
    try {
      const ex = window.examplesByChar?.[ch];
      if (ex && (ex.pinyin || ex.py)) return String(ex.pinyin || ex.py || '');
    } catch {}
    try {
      const items = getActiveCollection()?.items || {};
      const key   = (typeof itemKeyForChar === 'function') ? itemKeyForChar(ch) : ch;
      const it    = items[key];
      if (it?.py) return String(it.py);
    } catch {}
    return '';
  }

  function normalizePerCharExamples(raw) {
    if (!raw) return [];
    let base = raw.sentences || raw.sents || raw.examples || raw.exs || raw.lines || raw.ex || null;
    if (!base && Array.isArray(raw)) base = raw;

    const out = [];
    if (Array.isArray(base)) {
      for (const s of base) {
        if (!s) continue;
        if (typeof s === 'string') {
          out.push({ cn: s, py: '', tr: '' });
        } else if (Array.isArray(s)) {
          out.push({ cn: String(s[0] ?? ''), py: String(s[1] ?? ''), tr: String(s[2] ?? '') });
        } else if (typeof s === 'object') {
          const cn = s.cn || s.zh || s.ch || s.han || s.s || s.chinese || '';
          const py = s.py || s.pinyin || s.p || '';
          const tr = s.en || s.gloss || s.eng || s.e || s.translation || s.t || '';
          if (cn || py || tr) out.push({ cn: String(cn), py: String(py), tr: String(tr) });
        }
      }
    }
    return out;
  }

  function buildExamplePoolForChar(ch) {
    const sids = window.indexMap?.[ch];
    const S    = window.sentences;
    const SP   = window.sentencePinyin;
    const ST   = window.sentenceTranslation;

    if (Array.isArray(sids) && Array.isArray(S) && Array.isArray(SP) && Array.isArray(ST) && sids.length) {
      const ok = !!S[(sids[0] || 1) - 1];
      if (ok) return { type: 'sid', list: sids.slice(), count: sids.length };
    }

    const raw = window.examplesByChar?.[ch] || null;
    const inline = normalizePerCharExamples(raw);
    return { type: 'inline', list: inline, count: inline.length };
  }

  function resolveExample(pool, idx) {
    if (!pool || !pool.list || !pool.list.length) return { cn: '', py: '', tr: '' };

    if (pool.type === 'sid') {
      const sid = Number(pool.list[idx % pool.list.length]) || 0; // 1-based
      const i   = Math.max(0, sid - 1);
      const S   = window.sentences || [];
      const SP  = window.sentencePinyin || [];
      const ST  = window.sentenceTranslation || [];
      return { cn: String(S[i] || ''), py: String(SP[i] || ''), tr: String(ST[i] || '') };
    } else {
      const ex = pool.list[idx % pool.list.length] || { cn:'', py:'', tr:'' };
      return { cn: String(ex.cn || ''), py: String(ex.py || ''), tr: String(ex.tr || ex.en || '') };
    }
  }

  /* =========================
   * Lightweight record lookup (char-level)
   * ========================= */
  function adGetRec(ch) {
    const col   = (typeof getActiveCollection === 'function') ? getActiveCollection() : null;
    const items = col?.items || {};
    const key   = (typeof itemKeyForChar === 'function') ? itemKeyForChar(ch) : ch;
    const it    = items[key] || null;
    const py    = pinyinForChar(ch);
    const gloss = it?.m || it?.gloss || '';
    const level = it?.level ?? 0;
    return { ch, py, gloss, level };
  }

  /* =========================
   * Pleco launcher (mobile only, no web fallback)
   * ========================= */
  function openPleco(query) {
    if (!IS_MOBILE || !query) return;
    const q = encodeURIComponent(String(query));
    const scheme1 = `plecoapi://x-callback-url/s?q=${q}`;
    const scheme2 = `plecoapi://search?q=${q}`;

    // Use location-based scheme navigation on mobile.
    // No web fallback to avoid NXDOMAIN error screens when returning.
    try { window.location.href = scheme1; } catch {}
    // Try the alternate scheme shortly after.
    setTimeout(() => {
      try { window.location.href = scheme2; } catch {}
    }, 250);
  }

  /* =========================
   * DOM / overlay
   * ========================= */

  const LS_CHAR = 'ad.font.char';
  const LS_SENT = 'ad.font.sent';
  function readFontPx(k, fallback) {
    const v = Number(localStorage.getItem(k));
    return (isFinite(v) && v > 6) ? v : fallback;
  }
  let _fontCharPx = readFontPx(LS_CHAR, 32);
  let _fontSentPx = readFontPx(LS_SENT, 16);

  function ensureAudioDrillDOM() {
    let wrap = document.getElementById('audioDrillOverlay');
    if (wrap) return wrap;

    wrap = document.createElement('div');
    wrap.id = 'audioDrillOverlay';
    wrap.innerHTML = `
      <div class="ad-backdrop"></div>
      <div class="ad-card" role="dialog" aria-modal="true" aria-label="Audio Drill">

        <!-- floating yellow close button (top-right corner) -->
        <button id="adCloseBtn" class="btn small ad-close-float" title="Close" aria-label="Close">×</button>

        <header class="ad-header">
          <div class="ad-bar">
            <strong>Audio Drill</strong>
          </div>
          <div class="ad-controls">
            <label class="ad-slider">
              <span>Char</span>
              <input id="adCharSlider" type="range" min="16" max="96" step="1" />
              <span id="adCharVal"></span>
            </label>
            <label class="ad-slider">
              <span>Sentence</span>
              <input id="adSentSlider" type="range" min="10" max="32" step="1" />
              <span id="adSentVal"></span>
            </label>
            <button id="adAutoBtn" class="btn small" title="Auto-play reveal/next">Auto: OFF</button>
          </div>
        </header>

        <div class="ad-body" id="adBody">
          <button id="adActionBtn" class="btn action show" title="Reveal">Show ▶</button>
          <!-- replay speaker (visible before reveal) -->
          <button id="adReplayBtn" class="btn replay" title="Repeat sound" aria-label="Repeat">🔊</button>

          <div class="ad-mask" id="adMask">••</div>

          <div class="ad-reveal" id="adReveal" hidden>
            <div class="ad-hanzi"  id="adHanzi" title="Click to pronounce">汉</div>
            <div class="ad-pinyin" id="adPinyin">hàn</div>
            <div class="ad-occ"    id="adOcc"></div>
            <div class="ad-sent">
              <div class="ad-sent-cn" id="adSentCn" title="Click to pronounce"></div>
              <div class="ad-sent-py" id="adSentPy" title="Click to show another example"></div>
              <div class="ad-sent-en" id="adSentEn" title="Click to show another example"></div>
              <button id="adPlecoBtn" class="btn pleco" title="Open in Pleco" aria-label="Open in Pleco">📘 Pleco</button>
            </div>
            <div class="ad-meta"   id="adMeta">L0</div>
          </div>
        </div>

        <footer class="ad-footer">
          <span id="adProg">1 / 1</span>
          <span class="ad-hint">Tap to reveal • N/Space = next • R = reveal • A = auto • P = repeat</span>
        </footer>
      </div>
    `;
    document.body.appendChild(wrap);

    // Inline styles with dark mode + CSS vars
    const styleId = 'ad-inline-styles';
    if (!document.getElementById(styleId)) {
      const st = document.createElement('style');
      st.id = styleId;
      st.textContent = `
        :root {
          --ad-bg: #fff;
          --ad-fg: #111;
          --ad-muted: #666;
          --ad-card-shadow: 0 10px 25px rgba(0,0,0,.25);
          --ad-primary: #2563eb; /* blue for Show */
          --ad-accent: #16a34a;  /* green for Next */
          --ad-accent-fg: #fff;
          --ad-pleco-bg: #0ea5e9; /* cyan-ish for Pleco button */
          --ad-pleco-fg: #fff;
          --ad-close-bg: #facc15; /* yellow circle */
          --ad-close-fg: #111;
        }
        @media (prefers-color-scheme: dark) {
          :root {
            --ad-bg: #1f1f1f;
            --ad-fg: #eee;
            --ad-muted: #aaa;
            --ad-card-shadow: 0 10px 25px rgba(0,0,0,.6);
            --ad-close-fg: #1f1f1f;
          }
        }
        body.dark, html.dark {
          --ad-bg: #1f1f1f;
          --ad-fg: #eee;
          --ad-muted: #aaa;
          --ad-card-shadow: 0 10px 25px rgba(0,0,0,.6);
        }

        #audioDrillOverlay{position:fixed;inset:0;z-index:9999;display:none;}
        #audioDrillOverlay.open{display:block;}
        #audioDrillOverlay .ad-backdrop{position:absolute;inset:0;background:rgba(0,0,0,.45);}
        #audioDrillOverlay .ad-card{
          position:fixed;left:50%;top:50px;transform:translateX(-50%);
          width:min(760px,92vw);height:min(70vh,560px);
          background:var(--ad-bg);color:var(--ad-fg);
          border-radius:12px;box-shadow:var(--ad-card-shadow);
          display:flex;flex-direction:column;outline:none;
        }

        /* bigger yellow circular X at top-right */
        #audioDrillOverlay .ad-close-float{
          position:absolute;top:8px;right:8px;z-index:2;
          width:36px;height:36px;border-radius:50%;
          display:inline-flex;align-items:center;justify-content:center;
          background:var(--ad-close-bg);color:var(--ad-close-fg);
          border:none;cursor:pointer;font-size:22px;line-height:1;font-weight:700;
          box-shadow:0 2px 5px rgba(0,0,0,.25);
        }
        #audioDrillOverlay .ad-close-float:hover{filter:brightness(1.05);}
        #audioDrillOverlay .ad-close-float:active{transform:translateY(1px);}

        #audioDrillOverlay .ad-header{padding:8px 12px 4px 12px;border-bottom:1px solid rgba(127,127,127,.2);}
        #audioDrillOverlay .ad-bar{display:flex;align-items:center;justify-content:flex-start;gap:10px;}
        #audioDrillOverlay .ad-controls{display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-top:8px;}
        #audioDrillOverlay .ad-slider{display:flex;align-items:center;gap:6px;font-size:12px;color:var(--ad-muted);}
        #audioDrillOverlay .ad-slider input{width:120px;max-width:100%;}
        #audioDrillOverlay .btn.small{font-size:12px; padding:4px 8px;}

        #audioDrillOverlay .ad-body{
          position:relative;
          flex:1;display:flex;align-items:center;justify-content:center;padding:12px;
        }

        /* Floating action & replay buttons in the top-right of content area */
        #audioDrillOverlay .btn.action{
          position:absolute;right:10px;top:10px;
          border:none;border-radius:8px;padding:6px 10px;font-weight:600;cursor:pointer;
          box-shadow:0 1px 2px rgba(0,0,0,.2); color:#fff;
        }
        #audioDrillOverlay .btn.action.show{background:var(--ad-primary);}
        #audioDrillOverlay .btn.action.next{background:var(--ad-accent);}
        #audioDrillOverlay .btn.action:hover{filter:brightness(1.05);}
        #audioDrillOverlay .btn.action:active{transform:translateY(1px);}

#audioDrillOverlay .btn.replay{
  position:absolute;right:10px;top:48px;
  border:none;border-radius:8px;cursor:pointer;
  background:rgba(127,127,127,.2);color:var(--ad-fg);

  /* make the 🔊 larger */
  font-size:28px;    /* try 22–28px */
  line-height:1;
  padding:2px 8px;   /* optional: tighter padding */
}

        #audioDrillOverlay .btn.replay:hover{filter:brightness(1.05);}

        #audioDrillOverlay .ad-mask{font-size:40px;opacity:.35;}
        #audioDrillOverlay .ad-hanzi{font-size: var(--ad-char-px, 32px); line-height:1.2; text-align:center; margin-bottom:6px; cursor:pointer;}
        #audioDrillOverlay .ad-pinyin{font-size: var(--ad-sent-px, 16px); text-align:center; opacity:.95; margin-bottom:4px;}
        #audioDrillOverlay .ad-occ{font-size:12px; text-align:center; opacity:.7; margin-bottom:8px;}
        #audioDrillOverlay .ad-sent{margin-top:2px; text-align:center;}
        #audioDrillOverlay .ad-sent-cn{font-size: calc(var(--ad-sent-px, 16px) + 6px); cursor:pointer;}
        #audioDrillOverlay .ad-sent-py{font-size: var(--ad-sent-px, 16px); opacity:.95; cursor:pointer;}
        #audioDrillOverlay .ad-sent-en{font-size: var(--ad-sent-px, 16px); opacity:.9; cursor:pointer;}
        #audioDrillOverlay .btn.pleco{
          margin-top:8px;
          border:none;border-radius:8px;padding:6px 10px;font-weight:600;cursor:pointer;
          background:var(--ad-pleco-bg);color:var(--ad-pleco-fg);
        }
        #audioDrillOverlay .btn.pleco:hover{filter:brightness(1.05);}

        #audioDrillOverlay .ad-meta{margin-top:8px; font-size:12px; opacity:.7; text-align:center;}
        #audioDrillOverlay .ad-footer{display:flex;justify-content:space-between;padding:8px 12px;border-top:1px solid rgba(127,127,127,.2);font-size:12px;color:var(--ad-muted);}

        @media (max-width: 640px){
          #audioDrillOverlay .ad-controls{flex-direction:column;align-items:flex-start;}
          #audioDrillOverlay .ad-slider{width:100%;}
          #audioDrillOverlay .ad-slider input{width:100%;}
        }
      `;
      document.head.appendChild(st);
    }

    // initialize sliders + CSS vars
    const card = wrap.querySelector('.ad-card');
    card.style.setProperty('--ad-char-px', `${_fontCharPx}px`);
    card.style.setProperty('--ad-sent-px', `${_fontSentPx}px`);

    const charSlider = wrap.querySelector('#adCharSlider');
    const sentSlider = wrap.querySelector('#adSentSlider');
    const charVal = wrap.querySelector('#adCharVal');
    const sentVal = wrap.querySelector('#adSentVal');

    if (charSlider && sentSlider) {
      charSlider.value = String(_fontCharPx);
      sentSlider.value = String(_fontSentPx);
      if (charVal) charVal.textContent = `${_fontCharPx}px`;
      if (sentVal) sentVal.textContent = `${_fontSentPx}px`;

      charSlider.addEventListener('input', (e)=>{
        e.stopPropagation();
        _fontCharPx = Number(charSlider.value) || 32;
        card.style.setProperty('--ad-char-px', `${_fontCharPx}px`);
        localStorage.setItem(LS_CHAR, String(_fontCharPx));
        if (charVal) charVal.textContent = `${_fontCharPx}px`;
      });

      sentSlider.addEventListener('input', (e)=>{
        e.stopPropagation();
        _fontSentPx = Number(sentSlider.value) || 16;
        card.style.setProperty('--ad-sent-px', `${_fontSentPx}px`);
        localStorage.setItem(LS_SENT, String(_fontSentPx));
        if (sentVal) sentVal.textContent = `${_fontSentPx}px`;
      });
    }

    // Hide Pleco controls on desktop
    if (!IS_MOBILE) {
      const plecoBtn = wrap.querySelector('#adPlecoBtn');
      if (plecoBtn) plecoBtn.style.display = 'none';
    }

    return wrap;
  }

  /* =========================
   * Session state + helpers
   * ========================= */
  const _ad = {
    pool: [],
    i: 0,
    revealed: false,
    auto: false,
    tReveal: null,
    tNext: null,
    REVEAL_MS: 900,
    NEXT_MS: 700,
    exPool: null,
    exIdx: 0
  };

function adSpeak(chOrText) {
  const rate = getDrillTTSRate();
  const canWeb = ('speechSynthesis' in window);
  const wantWeb = (rate !== 1) && canWeb; // use Web Speech whenever a non-1.0 rate is requested

  try {
    // If we want a non-default rate and can use Web Speech, do that (guarantees rate works).
    if (wantWeb) {
      const u = new SpeechSynthesisUtterance(String(chOrText));
      u.rate = rate;              // <-- the slider value is honored here
      window.speechSynthesis.cancel();
      window.speechSynthesis.speak(u);
      return;
    }

    // Otherwise fall back to the app's TTS the way it already works:
    if (typeof speakNow === 'function') {
      // Try with options or numeric rate; if the app ignores it, it’ll behave like before.
      try { speakNow(chOrText, { rate }); }
      catch { speakNow(chOrText, rate); }
      return;
    }

    // Legacy hook some builds expose
    if (window.speakChar && window.speakChar._mhOrig) {
      window.speakChar._mhOrig(chOrText);
      return;
    }

    // Final fallback: Web Speech at default rate
    if (canWeb) {
      const u = new SpeechSynthesisUtterance(String(chOrText));
      u.rate = 1;
      window.speechSynthesis.cancel();
      window.speechSynthesis.speak(u);
    }
  } catch {}
}


  function adClearTimers() {
    if (_ad.tReveal) { clearTimeout(_ad.tReveal); _ad.tReveal = null; }
    if (_ad.tNext)   { clearTimeout(_ad.tNext);   _ad.tNext   = null; }
  }

  function updateOccurrencesLine() {
    const occEl = document.getElementById('adOcc');
    if (!occEl) return;
    const n = (_ad.exPool && Array.isArray(_ad.exPool.list)) ? _ad.exPool.list.length : 0;
    occEl.textContent = `Occurrences: ${n}`;
  }

  function showExample() {
    const { cn, py, tr } = resolveExample(_ad.exPool || { type:'inline', list:[] }, _ad.exIdx || 0);
    const cnEl = document.getElementById('adSentCn');
    const pyEl = document.getElementById('adSentPy');
    const trEl = document.getElementById('adSentEn');
    if (cnEl) cnEl.textContent = cn || '';
    if (pyEl) pyEl.textContent = py || '';
    if (trEl) trEl.textContent = tr || '';
    updateOccurrencesLine();
  }

  function cycleExample() {
    if (!_ad.exPool || !_ad.exPool.list || !_ad.exPool.list.length) return;
    _ad.exIdx = (_ad.exIdx + 1) % _ad.exPool.list.length;
    showExample();
  }

  function setActionButtonVisual() {
    const btn = document.getElementById('adActionBtn');
    const replay = document.getElementById('adReplayBtn');
    if (!btn) return;
    if (_ad.revealed) {
      btn.textContent = 'Next ▶';
      btn.classList.remove('show');
      btn.classList.add('next');
      btn.title = 'Next';
      if (replay) replay.style.display = 'none';
    } else {
      btn.textContent = 'Show ▶';
      btn.classList.remove('next');
      btn.classList.add('show');
      btn.title = 'Reveal';
      if (replay) replay.style.display = 'inline-block';
    }
  }

  function adRender() {
    ensureAudioDrillDOM();
    const step = _ad.pool[_ad.i];
    if (!step) { adFinish(); return; }

    const { ch, py, level } = adGetRec(step.ch);

    document.getElementById('adMask').hidden   = _ad.revealed;
    document.getElementById('adReveal').hidden = !_ad.revealed;

    document.getElementById('adHanzi').textContent  = ch || step.ch;
    document.getElementById('adPinyin').textContent = py || '';
    document.getElementById('adMeta').textContent   = `L${level ?? 0}`;
    document.getElementById('adProg').textContent   = `${_ad.i + 1} / ${_ad.pool.length}`;

    setActionButtonVisual();

    if (_ad.revealed) {
      adSpeakChar(step.ch);
      showExample();
    } else {
      adSpeakChar(step.ch);
      const cnEl = document.getElementById('adSentCn');
      const pyEl = document.getElementById('adSentPy');
      const trEl = document.getElementById('adSentEn');
      if (cnEl) cnEl.textContent = '';
      if (pyEl) pyEl.textContent = '';
      if (trEl) trEl.textContent = '';
      updateOccurrencesLine();
    }
  }

  function adScheduleAuto() {
    adClearTimers();
    if (!_ad.auto) return;
    _ad.tReveal = setTimeout(adReveal, _ad.REVEAL_MS);
  }

  function adReveal() {
    _ad.revealed = true;
    adRender();
    if (_ad.auto) _ad.tNext = setTimeout(adNext, _ad.NEXT_MS);
  }

  function adNext() {
    _ad.revealed = false;
    _ad.i++;
    if (_ad.i >= _ad.pool.length) { adFinish(); return; }

    const nextCh = _ad.pool[_ad.i]?.ch || '';
    _ad.exPool = buildExamplePoolForChar(nextCh);
    _ad.exIdx  = 0;

    adRender();
    adScheduleAuto();
  }

  function adToggleAuto() {
    _ad.auto = !_ad.auto;
    const btn = document.getElementById('adAutoBtn');
    if (btn) btn.textContent = _ad.auto ? 'Auto: ON' : 'Auto: OFF';
    adScheduleAuto();
  }

  function adOpen(pool) {
    window.onBubbleDecision = null;

    _ad.pool = pool.map(p => (typeof p === 'string' ? { ch: p } : p));
    _ad.i = 0;
    _ad.revealed = false;
    adClearTimers();

    const firstCh = _ad.pool[0]?.ch || '';
    _ad.exPool = buildExamplePoolForChar(firstCh);
    _ad.exIdx  = 0;

    const wrap = ensureAudioDrillDOM();
    wrap.classList.add('open');

    if (!wrap._wired) {
      wrap._wired = true;

      document.getElementById('adBody').addEventListener('click', () => { !_ad.revealed ? adReveal() : adNext(); });
      document.getElementById('adCloseBtn').addEventListener('click', adClose);
      document.getElementById('adAutoBtn').addEventListener('click', (e)=>{ e.stopPropagation(); adToggleAuto(); });

      // Action button: Show (before reveal) / Next (after reveal)
      document.getElementById('adActionBtn').addEventListener('click', (e) => {
        e.stopPropagation();
        if (_ad.revealed) adNext(); else adReveal();
      });

      // Replay speaker (only before reveal)
      document.getElementById('adReplayBtn').addEventListener('click', (e) => {
        e.stopPropagation();
        const step = _ad.pool[_ad.i];
        if (step?.ch) adSpeakChar(step.ch);
      });

      // Character click: pronounce; if revealed AND on mobile, also open in Pleco
      document.getElementById('adHanzi').addEventListener('click', (e) => {
        e.stopPropagation();
        const step = _ad.pool[_ad.i];
        const ch = step?.ch || '';
if (ch) {
  adSpeakChar(ch);
  if (_ad.revealed && IS_MOBILE) openPleco(ch);
}

      });

      // Sentence interactions
      document.getElementById('adSentCn').addEventListener('click', (e) => {
        e.stopPropagation();
        const ex = resolveExample(_ad.exPool || {type:'inline', list:[]}, _ad.exIdx || 0);
        if (ex.cn) adSpeakSentence(ex.cn);

      });
      document.getElementById('adSentPy').addEventListener('click', (e) => { e.stopPropagation(); cycleExample(); });
      document.getElementById('adSentEn').addEventListener('click', (e) => { e.stopPropagation(); cycleExample(); });

      // Pleco button for the current sentence (mobile only)
      document.getElementById('adPlecoBtn').addEventListener('click', (e) => {
        e.stopPropagation();
        if (!IS_MOBILE) return; // desktop: do nothing
        const cn = (document.getElementById('adSentCn')?.textContent || '').trim();
        if (cn) openPleco(cn);
      });

      wrap.addEventListener('keydown', (e) => {
        const k = (e.key || '').toLowerCase();
        if (k === 'escape') { e.preventDefault(); adClose(); }
        else if (k === ' ' || k === 'enter') { e.preventDefault(); adNext(); }
        else if (k === 'r') { e.preventDefault(); adReveal(); }
        else if (k === 'a') { e.preventDefault(); adToggleAuto(); }
else if (k === 'p') { e.preventDefault(); adSpeakChar((_ad.pool[_ad.i] || {}).ch || ''); }
      });
    }

    // Hide Pleco button on desktop (in case DOM already built)
    if (!IS_MOBILE) {
      const plecoBtn = wrap.querySelector('#adPlecoBtn');
      if (plecoBtn) plecoBtn.style.display = 'none';
    }

    const card = wrap.querySelector('.ad-card');
    card?.setAttribute('tabindex', '-1');
    card?.focus();

    adRender();
    adScheduleAuto();
  }

  function adClose() {
    adClearTimers();
    document.getElementById('audioDrillOverlay')?.classList.remove('open');
  }

  function adFinish() {
    adClose();
    if (typeof showCenterToast === 'function') showCenterToast('Audio Drill complete!', 1400);
  }

  /* =========================
   * Public launcher
   * ========================= */

  function startDueAudioDrill() {
    const label = rangeText();

    let pool = buildL0SeenDueTomorrowPool(9999).map(p => p.ch);

    if (!pool.length) {
      const fallback = buildL0AnsweredPool(9999).map(p => p.ch);
      if (fallback.length) {
        if (typeof showCenterToast === 'function') {
          showCenterToast(`No L0 (seen) due tomorrow in range ${label} — using L0 answered items.`, 1900);
        }
        pool = fallback;
      }
    }

    if (!pool.length) {
      if (typeof showCenterToast === 'function') {
        showCenterToast(`No eligible Level-0 items in range ${label}.`, 1700);
      }
      return;
    }

    adOpen(pool);
  }

  window.startDueAudioDrill = startDueAudioDrill;
  window.buildL0SeenDueTomorrowPool = buildL0SeenDueTomorrowPool;

})();
