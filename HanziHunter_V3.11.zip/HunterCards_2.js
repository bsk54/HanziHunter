/* =========================================================
   MineHanzi — List Card Modal (DeepCards-style)
   File: listCards.js (full replacement)
   - Big Hanzi is clickable → opens Pleco with the character
   - CN line has an inline Pleco button → opens Pleco with the sentence
   - Click CN -> speak the sentence
   - Click Pinyin or Translation -> cycle to another sentence (if available)
   - Tap empty space on the card -> go to next card
   - Bottom action row now ONLY has the speaker (Pleco button removed)
   Dependencies:
     - #listOverlay + #listContent (from list.js)
     - #listCardOverlay (stub exists in your HTML) 
     - Globals mirrored to window by your app:
       chars, indexMap, sentences, sentencePinyin, sentenceTranslation, pyIndex, settings
   ========================================================= */

(function(){
  // ---------- Anchors ----------
  const listOverlay  = document.getElementById('listOverlay');
  const listContent  = document.getElementById('listContent');

  // Create overlay if missing
  let cardOverlay = document.getElementById('listCardOverlay');
  if (!cardOverlay){
    cardOverlay = document.createElement('div');
    cardOverlay.id = 'listCardOverlay';
    cardOverlay.className = 'hidden';
    cardOverlay.setAttribute('aria-modal','true');
    cardOverlay.setAttribute('role','dialog');
    cardOverlay.innerHTML = `<div class="listcard-backdrop"></div><div class="listcard-content"></div>`;
    document.body.appendChild(cardOverlay);
  }
  const backdrop = cardOverlay.querySelector('.listcard-backdrop');
  const content  = cardOverlay.querySelector('.listcard-content');


// Ensure CSS variables exist
(function ensureKaitiVars(){
  const root = document.documentElement;
  if (!getComputedStyle(root).getPropertyValue('--kaiti-stack').trim()){
    root.style.setProperty('--kaiti-stack',
      '"Kaiti SC","STKaiti","KaiTi","KaiTi_GB2312","DFKai-SB","BiauKai", serif');
  }
  if (!getComputedStyle(root).getPropertyValue('--ui-font').trim()){
    root.style.setProperty('--ui-font',
      'system-ui,-apple-system,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif');
  }
})();



// ---------- One-time style injection ----------
(function injectStylesOnce(){
  if (document.getElementById('mh-listcard-styles')) return;

  const css = `
#listCardOverlay.hidden { display: none; }
#listCardOverlay{
  position: fixed; inset: 0; z-index: 4000;
  display: flex; align-items: flex-start; justify-content: center;
  padding-top: 12vh;
}
#listCardOverlay .listcard-backdrop{
  position: absolute; inset: 0; background: rgba(0,0,0,.6);
}
#listCardOverlay .listcard-content{
  position: relative;
  z-index: 1;
  background: var(--card-bg);
  color: var(--text-main);
  width: 90%;
  max-width: 540px;
  border-radius: 12px;
  box-shadow: 0 10px 30px var(--shadow, rgba(0,0,0,.35));
  border: 1px solid rgba(0,0,0,.06);
  padding: 16px 16px 64px; /* bottom room for actions */
}

/* Close button (white × on orange) */
#listCardOverlay .lc-close{
  position: absolute;
  top: -10px; right: -10px;
  width: 33px; height: 33px;
  border: none; border-radius: 50%;
  background: var(--tone2, #FFC107);
  color: #fff;
  font-weight: 700;
  font-size: 20px;
  line-height: 33px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  box-shadow: 0 2px 8px rgba(0,0,0,.25);
}

/* Body */
#listCardOverlay .lc-body{
  display: flex; flex-direction: column; align-items: center; gap: 8px;
  text-align: center;
}
#listCardOverlay .lc-hanzi{
  font-size: 2.4rem;
  line-height: 1.1;
  cursor: pointer;                /* clickable -> Pleco (char) */
  user-select: none;
}
#listCardOverlay .lc-pinyin{ font-size: 1.2rem; color: var(--text-sub); cursor: default; }

/* Example block */
#listCardOverlay .lc-ex-cn{
  font-size: 1.1rem; margin-top: 6px; display:inline-flex; align-items:center; gap:8px;
}
#listCardOverlay .lc-ex-cn .lc-cn-text{ cursor:pointer; }
#listCardOverlay .lc-ex-py{ font-size: .95rem; color: var(--text-sub); cursor:pointer; }
#listCardOverlay .lc-ex-tr{ font-size: .95rem; color: var(--text-sub); cursor:pointer; }
#listCardOverlay .lc-ex-count{ font-size: .8rem; color: var(--text-sub); margin-top: 2px; }

/* Actions row */
#listCardOverlay .lc-actions{
  position: absolute; left: 0; right: 0; bottom: 10px;
  display: flex; align-items: center; justify-content: center; gap: 12px;
}
#listCardOverlay .lc-replay{
  border: none; border-radius: 8px; padding: 8px 12px; cursor: pointer;
  background: var(--tone3, #2196F3); color: #fff; box-shadow: 0 2px 10px var(--shadow, rgba(0,0,0,.2));
  font-size: 16px;
}

/* Pleco styling */
#listCardOverlay .pleco-button{
  background:#fcfcfc; color:#0066aa; border:1px solid #ccc; border-radius: 6px;
  padding: 4px 10px; font-size: .9rem; cursor:pointer;
}
#listCardOverlay .pleco-inline{
  padding: 2px 8px; font-size: .85rem; line-height: 1.2;
}

/* Prev / Next */
#listCardOverlay .lc-prev,
#listCardOverlay .lc-next{
  position: absolute; top: 12px;
  background: none; border: none; font-size: 1.2rem; cursor: pointer; z-index: 2;
  padding: 4px 8px;
  color: var(--text-sub);
}
#listCardOverlay .lc-prev{ left: 8px; }
#listCardOverlay .lc-next{ right: 40px; } /* leave room for close btn */
@media (max-width: 600px){
  #listCardOverlay .lc-prev, #listCardOverlay .lc-next{ top: 8px; }
}

/* Highlight style for CN line */
#listCardOverlay .hl{
  color:#2196F3;
  text-decoration: none;
}

/* Visual separation when opened from List modal */
#listCardOverlay .listcard-content { margin-bottom: 20px; }

/* === Kaiti support (Chinese only) ====================== */
/* Big Hanzi + Chinese sentence use Kaiti when .kaiti-on is set */
.kaiti-on #listCardOverlay .lc-hanzi,
.kaiti-on #listCardOverlay .lc-ex-cn .lc-cn-text {
  font-family: var(--kaiti-stack) !important;
}

/* Keep ALL pinyin in the UI font (not Kaiti) */
.kaiti-on #listCardOverlay .lc-pinyin,
.kaiti-on #listCardOverlay .lc-ex-py {
  font-family: var(--ui-font) !important;
}

/* Keep translation in UI font too (optional but consistent) */
.kaiti-on #listCardOverlay .lc-ex-tr {
  font-family: var(--ui-font) !important;
}
`;

  const style = document.createElement('style');
  style.id = 'mh-listcard-styles';
  style.textContent = css;
  document.head.appendChild(style);
})();


  // ---------- Helpers ----------
  function normalizeSid(v){
    const n = typeof v === 'number' ? v : parseInt(v, 10);
    return Number.isFinite(n) ? n : null;
  }
  function uniqueNumeric(arr){
    return Array.from(new Set(arr.map(normalizeSid).filter(n => n !== null)));
  }
  function safeRegEsc(s){ return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
  function highlightAll(hay, needle){
    if (!hay || !needle) return hay || '';
    const rx = new RegExp(safeRegEsc(needle), 'g');
    return hay.replace(rx, '<span class="hl">'+needle+'</span>');
  }
  function plural(n, one, many){ return n===1 ? one : many; }

  function callSpeakChar(ch){
    try {
      if (typeof window.speakChar === 'function') return window.speakChar(ch);
    } catch {}
    // Fallback TTS for a single char
    if ('speechSynthesis' in window){
      try { speechSynthesis.cancel(); } catch {}
      const u = new SpeechSynthesisUtterance(ch);
      try { u.lang = (window.settings?.lang || 'zh-CN'); } catch {}
      try { speechSynthesis.speak(u); } catch {}
    }
  }
  function callSpeakSentence(s){
    if (!s) return;
    try {
      if (typeof window.speakSentence === 'function') return window.speakSentence(s);
    } catch {}
    // Fallback TTS for a sentence
    if ('speechSynthesis' in window){
      try { speechSynthesis.cancel(); } catch {}
      const u = new SpeechSynthesisUtterance(s);
      try {
        u.lang = (window.settings?.lang || 'zh-CN');
        if (window.settings?.sentenceRate) u.rate = window.settings.sentenceRate;
      } catch {}
      try { speechSynthesis.speak(u); } catch {}
    }
  }
  function openPleco(text){
    try {
      if (typeof window.lookupInPleco === 'function') return window.lookupInPleco(text);
    } catch{}
    const q = encodeURIComponent(text || '');
    if (q) location.href = `plecoapi://x-callback-url/s?q=${q}`;
  }

  // Build an example pool for a char: either SIDs from indexMap, or plain examples from per-char maps
  function buildExamplePoolForChar(ch){
    // Prefer dataset SIDs (indexMap -> sentences arrays)
    const postings = (window.indexMap && window.indexMap[ch]) || [];
    const sidList = uniqueNumeric(postings);
    if (sidList.length){
      return { type: 'sid', items: sidList, count: sidList.length };
    }

    // Else try any per-char example map if present
    const sources = [
      (g)=> g.examplesByChar?.[ch],
      (g)=> g.sentencesByChar?.[ch],
      (g)=> g.sIndex?.[ch],
      (g)=> g.sentenceIndex?.[ch],
      (g)=> g.exIndex?.[ch],
    ];
    for (const pick of sources){
      try {
        const arr = pick(window);
        if (Array.isArray(arr) && arr.length){
          // Normalize shape
          const norm = arr.map(e => ({
            cn: e.cn ?? e.s ?? e.text ?? '',
            py: e.py ?? e.pinyin ?? '',
            tr: e.tr ?? e.en ?? e.translation ?? ''
          })).filter(o => o.cn || o.py || o.tr);
          if (norm.length) return { type: 'plain', items: norm, count: norm.length };
        }
      } catch {}
    }
    return { type: 'none', items: [], count: 0 };
  }

  // Resolve example at index into { cn, py, tr, sid }
  function resolveExample(ch, pool, idx){
    if (!pool || !pool.items || !pool.items.length) return { cn:'', py:'', tr:'', sid:null };
    if (pool.type === 'sid'){
      const sid = pool.items[idx % pool.items.length];
      const cn  = (window.sentences && window.sentences[sid - 1]) || '';
      const sp  = (window.sentencePinyin && window.sentencePinyin[sid - 1]) || '';
      const tr  = (window.sentenceTranslation && window.sentenceTranslation[sid - 1]) || '';
      // For the card we show full-sentence pinyin; single-char pinyin is only for the top line
      const py  = sp || '';
      return { cn, py, tr, sid };
    } else if (pool.type === 'plain'){
      const ex  = pool.items[idx % pool.items.length];
      return { cn: ex.cn || '', py: ex.py || '', tr: ex.tr || '', sid: null };
    }
    return { cn:'', py:'', tr:'', sid:null };
  }

  // ---------- Modal state ----------
  let order = [];      // [{ch, el}, ...] in current List order
  let idx   = 0;       // index within "order"
  let touchStartX = 0;

  // Card-local state for examples (pool + current example index)
  let cardState = null; // { ch, pool, exIdx }

  function rebuildOrderFromList(){
    order = [];
    if (!listContent) return;
    const rows = listContent.querySelectorAll('.stat-item[data-ch]');
    rows.forEach(el=>{
      const ch = el.getAttribute('data-ch');
      if (ch) order.push({ ch, el });
    });
  }

  function initStateForChar(ch){
    cardState = {
      ch,
      pool: buildExamplePoolForChar(ch),
      exIdx: 0
    };
  }

  function ensureCardTapToNext(){
    // Avoid binding multiple times
    if (content._tapToNextBound) return;
    content._tapToNextBound = true;

    content.addEventListener('click', (e)=>{
      // Only when visible
      if (cardOverlay.classList.contains('hidden')) return;

      // Ignore clicks on interactive or line elements that have their own handlers
      const ignore = e.target.closest(
        '.lc-close, .lc-prev, .lc-next, .lc-replay, .pleco-button, ' +
        '.lc-ex-cn, .lc-ex-py, .lc-ex-tr, .lc-hanzi'
      );
      if (ignore) return;

      // Otherwise, advance to next card (same as swipe right->left)
      goNext();
    });
  }

  function renderCardSkeleton(){
    if (!order.length || !cardState) return;
    const ch = cardState.ch;

    content.innerHTML = `
      <button class="lc-close" title="Close" aria-label="Close">&times;</button>
      <button class="lc-prev"  title="Previous" aria-label="Previous">❮</button>
      <button class="lc-next"  title="Next" aria-label="Next">❯</button>

      <div class="lc-body">
        <div class="lc-hanzi" title="Open in Pleco">${ch}</div>
        <div class="lc-pinyin"></div>
        <div class="lc-ex-count"></div>

        <div class="lc-ex-cn">
          <span class="lc-cn-text"></span>
          <button class="pleco-button pleco-inline" title="Open sentence in Pleco">P</button>
        </div>

        <div class="lc-ex-py"></div>
        <div class="lc-ex-tr"></div>

        <div class="lc-actions">
          <button class="lc-replay" title="Replay">🔊</button>
        </div>
      </div>
    `;

    // Top controls
    content.querySelector('.lc-close') .addEventListener('click', closeCard);
    content.querySelector('.lc-prev')  .addEventListener('click', goPrev);
    content.querySelector('.lc-next')  .addEventListener('click', goNext);

    // Bottom action (speaker only)
    content.querySelector('.lc-replay').addEventListener('click', ()=> callSpeakChar(ch));

    // Big Hanzi -> Pleco (character)
    const hanziEl = content.querySelector('.lc-hanzi');
    hanziEl.addEventListener('click', (e)=>{
      e.preventDefault();
      e.stopPropagation();
      openPleco(ch);
    });

    // Interactive lines
    const cnTextEl = content.querySelector('.lc-cn-text');
    const cnLineEl = content.querySelector('.lc-ex-cn');
    const pyEl     = content.querySelector('.lc-ex-py');
    const trEl     = content.querySelector('.lc-ex-tr');
    const plecoInline = content.querySelector('.lc-ex-cn .pleco-inline');

    // Inline Pleco opens the full CN sentence
    plecoInline.addEventListener('click', (e)=>{
      e.preventDefault(); e.stopPropagation();
      const s = cnTextEl.textContent.trim();
      openPleco(s || ch);
    });

    // Click CN sentence => speak the sentence (ignore clicks on inline Pleco)
    cnLineEl.addEventListener('click', (e)=>{
      if (e.target.closest('.pleco-button')) return; // handled by its own listener
      const s = cnTextEl.textContent.trim();
      if (s) callSpeakSentence(s);
    });

    // Click Pinyin => show another example (if any)
    pyEl.addEventListener('click', ()=>{
      const n = cardState?.pool?.items?.length || 0;
      if (n > 1){
        cardState.exIdx = (cardState.exIdx + 1) % n;
        renderCardBody(); // re-render texts
      }
    });

    // Click Translation => show another example (if any)
    trEl.addEventListener('click', ()=>{
      const n = cardState?.pool?.items?.length || 0;
      if (n > 1){
        cardState.exIdx = (cardState.exIdx + 1) % n;
        renderCardBody();
      }
    });

    // Enable “tap anywhere on the card background to go next”
    ensureCardTapToNext();
  }

  function renderCardBody(){
    if (!cardState) return;
    const { ch, pool, exIdx } = cardState;
    const ex  = resolveExample(ch, pool, exIdx);

    const pinyinTopEl = content.querySelector('.lc-pinyin');
    const countEl     = content.querySelector('.lc-ex-count');
    const cnTextEl    = content.querySelector('.lc-cn-text');
    const pyEl        = content.querySelector('.lc-ex-py');
    const trEl        = content.querySelector('.lc-ex-tr');
    const plecoInline = content.querySelector('.lc-ex-cn .pleco-inline');

    if (!pinyinTopEl || !countEl || !cnTextEl || !pyEl || !trEl || !plecoInline) return;

    // Top pinyin (single-character pinyin, prefer pyIndex)
    let charPy = '';
    try {
      const arr = (window.pyIndex && window.pyIndex[ch]) || [];
      charPy = arr[0]?.py || '';
    } catch {}
    pinyinTopEl.textContent = charPy || '';

    // Count under pinyin
    const n = pool?.items?.length || 0;
    countEl.textContent = n ? `${n} ${plural(n, 'sentence', 'sentences')}` : `0 sentences`;

    // Chinese sentence with highlighted char
    const cnHtml = ex.cn ? highlightAll(ex.cn, ch) : '';
    cnTextEl.innerHTML = cnHtml; // innerHTML intentional for highlight

    // Inline Pleco opens the full CN sentence (update target if sentence changed)
    plecoInline.onclick = (e)=>{
      e.preventDefault(); e.stopPropagation();
      openPleco(ex.cn || ch);
    };

    // Pinyin + Translation for this example
    pyEl.textContent = ex.py || '';
    trEl.textContent = ex.tr || '';
  }

  function renderCard(){
    renderCardSkeleton();
    renderCardBody();
    // Auto-speak the character on open (unchanged behavior)
    try { callSpeakChar(cardState.ch); } catch {}
  }

function openCardAtRow(rowEl){
  if (!rowEl) return;
  rebuildOrderFromList();
  const ch = rowEl.getAttribute('data-ch');
  const pos = order.findIndex(o=>o.ch === ch);
  idx = Math.max(0, pos);
  initStateForChar(order[idx].ch);
  renderCard();

  // NEW: count the card we just opened
  // if (typeof window.incrementCardView === 'function') incrementCardView(ch);

  cardOverlay.classList.remove('hidden');
}


// Center the current list row in the underlying HanziList (if it is open)
function scrollListToCurrent({ smooth = true, center = true } = {}){
  const lo = document.getElementById('listOverlay');
  if (!lo || !lo.classList.contains('open')) return;

  const ch = order?.[idx]?.ch;
  if (!ch) return;

  // Ensure we have listContent from the top of this module
  if (!listContent) return;

  // Try to find the row for this character; re-render list if needed (rare)
  const esc = (window.CSS && CSS.escape) ? CSS.escape(ch) : ch.replace(/"/g, '\\"');
  let row = listContent.querySelector(`.stat-item[data-ch="${esc}"]`);
  if (!row && typeof window.renderListModal === 'function'){
    renderListModal();
    row = listContent.querySelector(`.stat-item[data-ch="${esc}"]`);
  }
  if (row){
    row.scrollIntoView({
      block: center ? 'center' : 'nearest',
      behavior: smooth ? 'smooth' : 'auto'
    });
  }
}




function closeCard(){
  cardOverlay.classList.add('hidden');

  // Refresh the underlying List so per-row counters & "Views: N" badge update
  const lo = document.getElementById('listOverlay');
  if (lo && lo.classList.contains('open') && typeof window.renderListModal === 'function') {
    renderListModal();
    // NEW: after re-render, scroll to the current character's row and center it
    scrollListToCurrent({ smooth: true, center: true });
  }
}


function goPrev(){
  if (!order.length) return;
  idx = (idx - 1 + order.length) % order.length;
  initStateForChar(order[idx].ch);
  renderCard();

  // NEW: keep the underlying list centered on the current card (if list is open)
  scrollListToCurrent({ smooth: true, center: true });
}

function goNext(){
  if (!order.length) return;
  idx = (idx + 1) % order.length;
  initStateForChar(order[idx].ch);
  renderCard();

  // NEW: keep the underlying list centered on the current card (if list is open)
  scrollListToCurrent({ smooth: true, center: true });
}


  // ---------- Intercept clicks from List (capture to override list.js speak) ----------
// ---------- Intercept clicks from List (capture to override list.js speak) ----------
document.addEventListener('click', (e)=>{
  if (!listOverlay || !listOverlay.classList.contains('open')) return;

  // IMPORTANT: do not open a card when tapping the Pinyin column
  // NOTE: List→Card capture handler. MUST ignore Pinyin clicks so List can toggle.

  if (e.target.closest('.pinyin-cell, .stat-pinyin')) return;

  // Let List’s Pleco button work
  if (e.target.closest('.pleco-button')) return;

  const row = e.target.closest('#listContent .stat-item[data-ch]');
  if (!row) return;

  e.preventDefault();
  e.stopImmediatePropagation();
  openCardAtRow(row);
}, true);


// ---------- Backdrop + keys ----------
// ---------- Backdrop + keys ----------

// Close when clicking the dark backdrop behind the card.
// Also stop propagation so nothing underneath (e.g., List overlay) reacts.
backdrop.addEventListener('click', (e) => {
  e.stopPropagation();
  closeCard();
});

// Important: prevent ESC / Arrow key events from bubbling to global listeners
// (e.g., the List overlay’s onGlobalKeys), which would otherwise close the List
// and send the user back to the entry screen.
document.addEventListener('keydown', (e) => {
  if (cardOverlay.classList.contains('hidden')) return;

  // Normalize the key
  const key = e.key;

  if (key === 'Escape') {
    e.preventDefault();
    // Stop *all* other keydown handlers from seeing this ESC (esp. List’s).
    e.stopImmediatePropagation();
    closeCard();
    return;
  }

  if (key === 'ArrowLeft') {
    e.preventDefault();
    e.stopImmediatePropagation();
    goPrev();
    return;
  }

  if (key === 'ArrowRight') {
    e.preventDefault();
    e.stopImmediatePropagation();
    goNext();
    return;
  }
}, /* use bubble phase */ false);


  // ---------- Swipe (mobile) ----------
  content.addEventListener('touchstart', (e)=>{ touchStartX = e.changedTouches[0].clientX; }, {passive:true});
  content.addEventListener('touchend',   (e)=>{
    const dx = e.changedTouches[0].clientX - touchStartX;
    const thresh = 40;
    if (dx >  thresh) goPrev();
    if (dx < -thresh) goNext();
  }, {passive:true});

  // ---------- Public API ----------
window.openListCardForChar = function(ch){
  if (!listContent) return;
  rebuildOrderFromList();
  const pos = order.findIndex(o=>o.ch === ch);
  idx = Math.max(0, pos);
  initStateForChar(ch);
  renderCard();

  // NEW
  // if (typeof window.incrementCardView === 'function') incrementCardView(ch);

  cardOverlay.classList.remove('hidden');
};


})();
