/**********************
 * Hanzi Drift — Full module (List-based pool)
 * - Entry prefs (settings.drift) restore/save
 * - Reads PHIDE (pinyin visibility) from localStorage
 * - **Pool source = characters shown in the List modal** (not just “due”)
 *   • Filter = All / Pinyin visible / Pinyin hidden (based on List PHIDE state)
 * - Threshold applies to a chosen metric:
 *   • t = r − w  (default)
 *   • w = total wrongs
 *   • r=0; W = wrongs (items where r==0 only; band on W)
 * - Play stage with moving characters (physics)
 * - Click a character => opens mini card (CN • Pinyin • EN • actions)
 * - Shortcuts: Esc/W = Keep, Enter/R = Remove, X = Exit to Entry
 * - Desktop-only bottom hints for shortcuts in Play view
 * - Sliders under stage: Speed, Bubble size, Character size (persisted)
 **********************/

/* =========================
   ENTRY: DOM refs
   ========================= */

// ---- Drift auto-speak tuning ----
const DRIFT_AUTO_SENTENCE_DELAY_MS = 1000;
const DRIFT_AUTO_SENTENCE_MAXLEN   = 10;

const driftOverlay    = document.getElementById('driftOverlay');
const driftEntry      = document.getElementById('driftEntry');
const driftPlay       = document.getElementById('driftPlay');

const driftMax        = document.getElementById('driftMax');
const driftMaxVal     = document.getElementById('driftMaxVal');

/* (legacy single cutoff; will be hidden if present) */
const driftT          = document.getElementById('driftT');
const driftTVal       = document.getElementById('driftTVal');

/* New band controls (injected if not in HTML) */
let driftCutMin       = document.getElementById('driftCutMin');
let driftCutMax       = document.getElementById('driftCutMax');
let driftCutMinVal    = document.getElementById('driftCutMinVal');
let driftCutMaxVal    = document.getElementById('driftCutMaxVal');
let driftThresholdLabelEl = null; // <label for="driftT">...</label>
let driftRangeWrap    = null;     // wrapper we inject
let driftRZeroRow     = null;     // static row for "r = 0" when metric=r0w
let driftMetricHelpEl = null;     // short friendly tip under metric radios

const driftFilterAll        = document.getElementById('driftFilterAll');
const driftFilterPyVisible  = document.getElementById('driftFilterPyVisible');
const driftFilterPyHidden   = document.getElementById('driftFilterPyHidden');

// Metric radios (injected by JS if not present in HTML)
let driftMetricT = document.getElementById('driftMetricT');
let driftMetricW = document.getElementById('driftMetricW');
let driftMetricR0W = document.getElementById('driftMetricR0W');
let driftMetricFieldset = document.getElementById('driftMetricFieldset');

const driftDueCount   = document.getElementById('driftDueCount');  // shows LIST count
const driftIncluded   = document.getElementById('driftIncluded');

const driftStartBtn   = document.getElementById('driftStartBtn');
const driftCancelBtn  = document.getElementById('driftCancelBtn');
const driftCloseBtn   = document.getElementById('driftClose');
const driftExitBtn    = document.getElementById('driftExitBtn');
const driftShuffleBtn = document.getElementById('driftShuffle');
const driftEndBackBtn = document.getElementById('driftEndBack');

/* =========================
   Controls under stage (sliders)
   ========================= */
const driftSpeed       = document.getElementById('driftSpeed');
const driftSpeedVal    = document.getElementById('driftSpeedVal');
const driftDotSize     = document.getElementById('driftDotSize');
const driftDotSizeVal  = document.getElementById('driftDotSizeVal');
const driftFontSize    = document.getElementById('driftFontSize');
const driftFontSizeVal = document.getElementById('driftFontSizeVal');

/* =========================
   Selection helpers
   ========================= */
function driftCurrentDatasetId(){
  return (window.settings && settings.datasetId) || '01';
}
function driftCurrentCollectionId(){
  return (typeof window.getActiveCollectionId === 'function') ? getActiveCollectionId() : 'default';
}
function driftCurrentRange(){
  const r = (window.settings && settings.range) || {min:1, max:(Array.isArray(window.chars) ? chars.length : 1)};
  const min = Math.max(1, parseInt(r.min || 1, 10));
  const max = Math.max(min, parseInt(r.max || min, 10));
  return { min, max };
}

/* =========================
   PHide (pinyin visibility) for current selection
   ========================= */
const DRIFT_PHIDE_PREFIX = (typeof window.PHIDE_PREFIX !== 'undefined' ? PHIDE_PREFIX : 'MH_PHIDE_v1');
function driftPHideKey(ds, col, min, max){ return `${DRIFT_PHIDE_PREFIX}:${ds}:${col}:${min}-${max}`; }

function driftLoadPHideForSelection(){
  const {min, max} = driftCurrentRange();
  const ds  = String(driftCurrentDatasetId());
  const col = String(driftCurrentCollectionId());

  const exactKey = driftPHideKey(ds, col, min, max);
  try {
    const raw = localStorage.getItem(exactKey);
    if (raw) {
      const obj = JSON.parse(raw);
      if (obj && typeof obj === 'object') return {
        defaultVisible: !!obj.default,
        overrides: (obj.overrides && typeof obj.overrides === 'object') ? obj.overrides : {}
      };
    }
  } catch {}

  // Forward migration: find largest stored subset within current [min,max]
  const prefix = `${DRIFT_PHIDE_PREFIX}:${ds}:${col}:`;
  let best = null;
  try {
    for (let i=0;i<localStorage.length;i++){
      const k = localStorage.key(i);
      if (!k || !k.startsWith(prefix)) continue;
      const mm = k.substring(prefix.length).match(/^(\d+)-(\d+)$/);
      if (!mm) continue;
      const m = Number(mm[1]), M = Number(mm[2]);
      if (m >= min && M <= max){
        const raw = localStorage.getItem(k);
        const obj = raw ? JSON.parse(raw) : null;
        if (!obj || typeof obj !== 'object') continue;
        if (!best || (M - m) > (best.max - best.min)) best = { min:m, max:M, obj };
      }
    }
  } catch {}
  if (best && best.obj){
    return {
      defaultVisible: !!best.obj.default,
      overrides: (best.obj.overrides && typeof best.obj.overrides === 'object') ? best.obj.overrides : {}
    };
  }
  return { defaultVisible: true, overrides: {} };
}

function driftIsPinyinVisibleFactory(ph){
  const def = !!ph.defaultVisible;
  const ov  = ph.overrides || {};
  return function(ch){ return (ch in ov) ? !!ov[ch] : def; };
}

/* =========================
   LIST-BASED POOL (instead of “due”)
   ========================= */
/**
 * Primary: use gatherSortedRecords() if present (same list that List modal would render)
 * Fallback A: read the DOM (#listContent .stat-item[data-ch]) if already rendered
 * Fallback B: slice from global chars[] using current range (unsorted)
 */
function driftBuildListChars(){
  // A) Preferred: compute via gatherSortedRecords() (from list2.js / list3.js)
  try {
    if (typeof window.gatherSortedRecords === 'function'){
      const recs = gatherSortedRecords() || [];
      const arr  = recs.map(r => r.ch).filter(Boolean);
      if (arr.length) return arr;
    }
  } catch {}

  // B) If the modal has been rendered, use its DOM order
  try {
    const listContent = document.getElementById('listContent');
    if (listContent){
      const rows = listContent.querySelectorAll('.stat-item[data-ch]');
      if (rows && rows.length){
        return Array.from(rows).map(el => el.getAttribute('data-ch')).filter(Boolean);
      }
    }
  } catch {}

  // C) Fallback: current range slice of global chars (unsorted)
  try {
    const all = Array.isArray(window.chars) ? window.chars.slice() : [];
    if (!all.length) return [];
    const {min, max} = driftCurrentRange();
    return all.slice(Math.max(0,min-1), Math.max(0, max));
  } catch {}
  return [];
}

/* Scores */
function driftScoreT(ch){
  try {
    const it = (typeof window.getOrCreateItem === 'function') ? getOrCreateItem(ch) : null;
    const r = it?.r || 0, w = it?.w || 0;
    return (r - w);
  } catch { return 0; }
}
function driftScoreW(ch){
  try {
    const it = (typeof window.getOrCreateItem === 'function') ? getOrCreateItem(ch) : null;
    return it?.w || 0;
  } catch { return 0; }
}
function driftScoreR(ch){
  try {
    const it = (typeof window.getOrCreateItem === 'function') ? getOrCreateItem(ch) : null;
    return it?.r || 0;
  } catch { return 0; }
}

/* =========================
   Metric selection (UI + logic)
   ========================= */
const DRIFT_METRIC_T   = 't';
const DRIFT_METRIC_W   = 'w';
const DRIFT_METRIC_R0W = 'r0w';

const DRIFT_DEFAULTS = {
  maxOnScreen: 10,
  metric: DRIFT_METRIC_T, // 't' | 'w' | 'r0w'
  // legacy single thresholds (kept for migration only)
  tThreshold: -3,
  wThreshold: 0,
  // new band ranges (inclusive)
  tMin: -3,
  tMax:  1,
  wMin:  0,
  wMax:  2,
  // r=0; W band (defaults ensure w>0 by default)
  w0Min: 1,
  w0Max:  2,
  filter: 'all',
  speedScale: 2.0,  // 1.0..4.0 step .2 (multiplier)
  dotSize: 44,      // px
  charSize: 28      // px (font-size)
};

function driftClampNum(v, lo, hi, fallback){
  const n = Number(v);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(hi, Math.max(lo, n));
}

/** Create the Metric radios if they’re not in the HTML */
function driftEnsureMetricControls(){
  if (!driftEntry) return;

  const filterFieldset = driftEntry.querySelector('.drift-fieldset');

  if (!driftMetricFieldset){
    const fs = document.createElement('fieldset');
    fs.className = 'drift-fieldset';
    fs.id = 'driftMetricFieldset';
    fs.innerHTML = `
      <legend>How do you want to pick items?</legend>
      <label class="drift-radio">
        <input type="radio" name="driftMetric" id="driftMetricT" value="t">
        Score (t) = right − wrong &nbsp;<span style="opacity:.7">(lower t ⇒ trickier)</span>
      </label>
      <label class="drift-radio">
        <input type="radio" name="driftMetric" id="driftMetricW" value="w">
        Wrongs (W) = total times wrong
      </label>
      <label class="drift-radio">
        <input type="radio" name="driftMetric" id="driftMetricR0W" value="r0w">
        Brand-new only: right = 0; filter by Wrongs (W)
      </label>
      <div id="driftMetricHelp" style="margin-top:6px;font-size:.92rem;opacity:.85"></div>
    `;
    if (filterFieldset && filterFieldset.parentNode){
      filterFieldset.parentNode.insertBefore(fs, filterFieldset.nextSibling);
    } else {
      const body = driftEntry.querySelector('.drift-body') || driftEntry;
      body.insertBefore(fs, body.firstChild);
    }
    driftMetricFieldset = fs;
    driftMetricT   = fs.querySelector('#driftMetricT');
    driftMetricW   = fs.querySelector('#driftMetricW');
    driftMetricR0W = fs.querySelector('#driftMetricR0W');
    driftMetricHelpEl = fs.querySelector('#driftMetricHelp');
  }

  if (!driftThresholdLabelEl){
    driftThresholdLabelEl = driftEntry.querySelector('label[for="driftT"]') || null;
  }

  // Inject band controls (and hide legacy single slider if present)
  driftEnsureBandControls();
}

/** Inject two range sliders for an inclusive band (min ≥, max ≤)
 *  + a static "r = 0" row we show only when metric = r0w
 */
function driftEnsureBandControls(){
  if (!driftEntry) return;

  if (!driftRangeWrap){
    // Find the container to place the band just after the old label/slider
    const anchor = driftThresholdLabelEl?.parentElement || driftEntry;
    const wrap = document.createElement('div');
    wrap.id = 'driftRangeWrap';
    wrap.className = 'drift-range-wrap';
    wrap.innerHTML = `
      <div class="drift-range-row" id="driftRZeroRow" style="display:none">
        <label style="font-weight:600">Brand-new only</label>
        <span aria-hidden="true" style="opacity:.8">r = 0</span>
      </div>
      <div class="drift-range-row">
        <label id="driftCutMinLabel" for="driftCutMin">Range: include scores ≥</label>
        <input type="range" id="driftCutMin" min="0" max="10" step="1" aria-label="Minimum score to include">
        <span id="driftCutMinVal">0</span>
      </div>
      <div class="drift-range-row">
        <label id="driftCutMaxLabel" for="driftCutMax">Range: include scores ≤</label>
        <input type="range" id="driftCutMax" min="0" max="10" step="1" aria-label="Maximum score to include">
        <span id="driftCutMaxVal">10</span>
      </div>
    `;
    if (anchor && anchor.parentNode){
      anchor.parentNode.insertBefore(wrap, anchor.nextSibling);
    } else {
      const body = driftEntry.querySelector('.drift-body') || driftEntry;
      body.appendChild(wrap);
    }
    driftRangeWrap = wrap;

    driftRZeroRow  = wrap.querySelector('#driftRZeroRow');
    driftCutMin    = wrap.querySelector('#driftCutMin');
    driftCutMax    = wrap.querySelector('#driftCutMax');
    driftCutMinVal = wrap.querySelector('#driftCutMinVal');
    driftCutMaxVal = wrap.querySelector('#driftCutMaxVal');
  }

  // Hide legacy single slider UI (if present)
  try {
    const legacyRow = driftT?.closest('.drift-range-row') || driftT?.parentElement;
    if (legacyRow) legacyRow.style.display = 'none';
    if (driftThresholdLabelEl) driftThresholdLabelEl.style.display = 'none';
    if (driftT) { driftT.style.display = 'none'; if (driftTVal) driftTVal.style.display = 'none'; }
  } catch {}
}

function driftUpdateMetricHelp(metric){
  if (!driftMetricHelpEl) return;
  if (metric === DRIFT_METRIC_W){
    driftMetricHelpEl.textContent = 'Pick words by how many times you got them wrong. Higher W = harder.';
  } else if (metric === DRIFT_METRIC_R0W){
    driftMetricHelpEl.textContent = 'Show only brand-new items (right = 0). Use the sliders to choose how many wrongs (W).';
  } else {
    driftMetricHelpEl.textContent = 'Score t = right − wrong. Lower t usually means trickier words. Use the band to target a difficulty window.';
  }
}

function driftGetMetric(){
  const m = (settings.drift && settings.drift.metric) || DRIFT_DEFAULTS.metric;
  if (driftMetricT?.checked)   return DRIFT_METRIC_T;
  if (driftMetricW?.checked)   return DRIFT_METRIC_W;
  if (driftMetricR0W?.checked) return DRIFT_METRIC_R0W;
  return m;
}

function driftSetMetric(m){
  const metric = (m === DRIFT_METRIC_W) ? DRIFT_METRIC_W : (m === DRIFT_METRIC_R0W ? DRIFT_METRIC_R0W : DRIFT_METRIC_T);
  if (!settings.drift) settings.drift = {...DRIFT_DEFAULTS};
  settings.drift.metric = metric;
  if (typeof window.saveSettings === 'function') saveSettings();

  if (driftMetricT)   driftMetricT.checked   = (metric === DRIFT_METRIC_T);
  if (driftMetricW)   driftMetricW.checked   = (metric === DRIFT_METRIC_W);
  if (driftMetricR0W) driftMetricR0W.checked = (metric === DRIFT_METRIC_R0W);

  driftUpdateMetricHelp(metric);
  driftConfigureBandUI(metric);
  driftUpdatePreview();
}

/** Compute W domain from current pool & filter */
function driftComputeWDomain(){
  const filter = driftCurrentFilterFromUI();
  const listChars = driftBuildListChars();

  const ph       = driftLoadPHideForSelection();
  const pyVisPH  = driftIsPinyinVisibleFactory(ph);
  const pyVisDOM = driftBuildPyVisFromDOM();
  const pyVis = (ch) => {
    if (pyVisDOM){
      const v = pyVisDOM(ch);
      if (v !== null) return v;
    }
    return pyVisPH(ch);
  };

  let pool = listChars;
  if (filter === 'py-visible') pool = listChars.filter(ch =>  pyVis(ch));
  if (filter === 'py-hidden')  pool = listChars.filter(ch => !pyVis(ch));

  let maxW = 0;
  for (const ch of pool){
    const w = driftScoreW(ch);
    if (w > maxW) maxW = w;
  }
  const domainMax = Math.max(5, Math.min(99, maxW + 1));
  return { min: 0, max: domainMax, step: 1 };
}

/** Compute W domain but restricted to items where r == 0 */
/** Compute W domain but restricted to items where r == 0 */
function driftComputeW0Domain(){
  const filter = driftCurrentFilterFromUI();
  const listChars = driftBuildListChars();

  const ph       = driftLoadPHideForSelection();
  const pyVisPH  = driftIsPinyinVisibleFactory(ph);
  const pyVisDOM = driftBuildPyVisFromDOM();
  const pyVis = (ch) => {
    if (pyVisDOM){
      const v = pyVisDOM(ch);
      if (v !== null) return v;
    }
    return pyVisPH(ch);
  };

  let pool = listChars;
  if (filter === 'py-visible') pool = listChars.filter(ch =>  pyVis(ch));
  if (filter === 'py-hidden')  pool = listChars.filter(ch => !pyVis(ch));

  let maxW = 0;
  let any  = false;
  for (const ch of pool){
    const r = driftScoreR(ch);
    if (r === 0){
      any = true;
      const w = driftScoreW(ch);
      if (w > maxW) maxW = w;
    }
  }
  const domainMax = any ? Math.max(1, Math.min(99, maxW + 1)) : 1;

  // IMPORTANT: lower bound must be 1 (never 0) for r=0 mode
  return { min: 1, max: domainMax, step: 1 };
}


/** Adaptive T domain from current pool & filter */
function driftComputeTDomain(){
  const filter = driftCurrentFilterFromUI();
  const listChars = driftBuildListChars();

  const ph       = driftLoadPHideForSelection();
  const pyVisPH  = driftIsPinyinVisibleFactory(ph);
  const pyVisDOM = driftBuildPyVisFromDOM();
  const pyVis = (ch) => {
    if (pyVisDOM){
      const v = pyVisDOM(ch);
      if (v !== null) return v;
    }
    return pyVisPH(ch);
  };

  let pool = listChars;
  if (filter === 'py-visible') pool = listChars.filter(ch =>  pyVis(ch));
  if (filter === 'py-hidden')  pool = listChars.filter(ch => !pyVis(ch));

  if (!pool.length) return { min: -10, max: 10, step: 1 };

  let minT = Infinity, maxT = -Infinity;
  for (const ch of pool){
    const t = driftScoreT(ch);
    if (t < minT) minT = t;
    if (t > maxT) maxT = t;
  }
  if (!Number.isFinite(minT) || !Number.isFinite(maxT)) return { min: -10, max: 10, step: 1 };

  let domMin = Math.max(-99, Math.floor(minT) - 1);
  let domMax = Math.min( 99, Math.ceil (maxT) + 1);
  if (domMax - domMin < 2){ domMin = Math.min(domMin, -10); domMax = Math.max(domMax, 10); }

  return { min: domMin, max: domMax, step: 1 };
}

/** Configure band labels/bounds/values to the active metric */
function driftConfigureBandUI(metric){
  if (!driftCutMin || !driftCutMax) return;

  const p = (settings.drift ||= {...DRIFT_DEFAULTS});
  const minLab = document.getElementById('driftCutMinLabel');
  const maxLab = document.getElementById('driftCutMaxLabel');

  if (metric === DRIFT_METRIC_W){
    const dom = driftComputeWDomain();
    driftCutMin.min = String(dom.min);
    driftCutMin.max = String(dom.max);
    driftCutMin.step = String(dom.step);
    driftCutMax.min = String(dom.min);
    driftCutMax.max = String(dom.max);
    driftCutMax.step = String(dom.step);

    const vMin = driftClampNum(p.wMin ?? DRIFT_DEFAULTS.wMin, dom.min, dom.max, DRIFT_DEFAULTS.wMin);
    const vMax = driftClampNum(p.wMax ?? DRIFT_DEFAULTS.wMax, dom.min, dom.max, DRIFT_DEFAULTS.wMax);
    driftCutMin.value = String(Math.min(vMin, vMax));
    driftCutMax.value = String(Math.max(vMin, vMax));

    if (minLab) minLab.textContent = 'Wrongs (W): include ≥';
    if (maxLab) maxLab.textContent = 'Wrongs (W): include ≤';
    if (driftRZeroRow) driftRZeroRow.style.display = 'none';
  } else if (metric === DRIFT_METRIC_R0W){
    const dom = driftComputeW0Domain();
    driftCutMin.min = String(dom.min);
    driftCutMin.max = String(dom.max);
    driftCutMin.step = String(dom.step);
    driftCutMax.min = String(dom.min);
    driftCutMax.max = String(dom.max);
    driftCutMax.step = String(dom.step);

    const vMin = driftClampNum(p.w0Min ?? DRIFT_DEFAULTS.w0Min, dom.min, dom.max, DRIFT_DEFAULTS.w0Min);
    const vMax = driftClampNum(p.w0Max ?? DRIFT_DEFAULTS.w0Max, dom.min, dom.max, DRIFT_DEFAULTS.w0Max);
    driftCutMin.value = String(Math.min(vMin, vMax));
    driftCutMax.value = String(Math.max(vMin, vMax));

    if (minLab) minLab.textContent = 'Wrongs (W): include ≥';
    if (maxLab) maxLab.textContent = 'Wrongs (W): include ≤';
    if (driftRZeroRow) driftRZeroRow.style.display = '';
  } else {
    const dom = driftComputeTDomain();
    driftCutMin.min  = String(dom.min);
    driftCutMin.max  = String(dom.max);
    driftCutMin.step = String(dom.step);
    driftCutMax.min  = String(dom.min);
    driftCutMax.max  = String(dom.max);
    driftCutMax.step = String(dom.step);

    const vMin = driftClampNum(p.tMin ?? DRIFT_DEFAULTS.tMin, dom.min, dom.max, DRIFT_DEFAULTS.tMin);
    const vMax = driftClampNum(p.tMax ?? DRIFT_DEFAULTS.tMax, dom.min, dom.max, DRIFT_DEFAULTS.tMax);
    driftCutMin.value = String(Math.min(vMin, vMax));
    driftCutMax.value = String(Math.max(vMin, vMax));

    if (minLab) minLab.textContent = 'Score (t): include ≥';
    if (maxLab) maxLab.textContent = 'Score (t): include ≤';
    if (driftRZeroRow) driftRZeroRow.style.display = 'none';
  }

  if (driftCutMinVal) driftCutMinVal.textContent = String(driftCutMin.value);
  if (driftCutMaxVal) driftCutMaxVal.textContent = String(driftCutMax.value);
}

/** Active band from UI or settings (inclusive) */
function driftCurrentBandFromUI(){
  const metric = driftGetMetric();
  const vMin = parseInt(driftCutMin?.value ?? '', 10);
  const vMax = parseInt(driftCutMax?.value ?? '', 10);
  if (Number.isFinite(vMin) && Number.isFinite(vMax)){
    return { min: Math.min(vMin, vMax), max: Math.max(vMin, vMax), metric };
  }

  const p = (settings.drift ||= {...DRIFT_DEFAULTS});
  if (metric === DRIFT_METRIC_W){
    return { min: p.wMin ?? DRIFT_DEFAULTS.wMin, max: p.wMax ?? DRIFT_DEFAULTS.wMax, metric };
  } else if (metric === DRIFT_METRIC_R0W){
    return { min: p.w0Min ?? DRIFT_DEFAULTS.w0Min, max: p.w0Max ?? DRIFT_DEFAULTS.w0Max, metric };
  } else {
    return { min: p.tMin ?? DRIFT_DEFAULTS.tMin, max: p.tMax ?? DRIFT_DEFAULTS.tMax, metric };
  }
}

/* Compute eligible set from LIST + filter + selected metric & band */
function driftCurrentFilterFromUI(){
  if (driftFilterPyVisible?.checked) return 'py-visible';
  if (driftFilterPyHidden?.checked)  return 'py-hidden';
  return 'all';
}

/* Prefer pinyin-visibility from the List DOM (live) */
function driftBuildPyVisFromDOM(){
  const listContent = document.getElementById('listContent');
  if (!listContent) return null;

  const map = new Map();
  listContent.querySelectorAll('.stat-pinyin[data-ch]').forEach(el=>{
    const ch = el.getAttribute('data-ch');
    const hiddenAttr = el.getAttribute('aria-hidden');
    let vis;
    if (hiddenAttr === 'true')      vis = false;
    else if (hiddenAttr === 'false')vis = true;
    else {
      const op = getComputedStyle(el).opacity;
      vis = !(op === '0');
    }
    if (ch) map.set(ch, vis);
  });

  return (ch)=>{
    if (!map.has(ch)) return null;
    return !!map.get(ch);
  };
}

function driftComputeEligible(){
  const band   = driftCurrentBandFromUI(); // {min,max,metric}
  const filter = driftCurrentFilterFromUI();
  const metric = band.metric;

  // Pool = what the List modal shows
  const listChars = driftBuildListChars();

  // Pinyin-visible resolver preferring DOM, then PHIDE
  const ph       = driftLoadPHideForSelection();
  const pyVisPH  = driftIsPinyinVisibleFactory(ph);
  const pyVisDOM = driftBuildPyVisFromDOM();
  const pyVis = (ch) => {
    if (pyVisDOM){
      const v = pyVisDOM(ch);
      if (v !== null) return v;
    }
    return pyVisPH(ch);
  };

  // Filter by Pinyin visibility
  let pool = listChars;
  if (filter === 'py-visible') pool = listChars.filter(ch =>  pyVis(ch));
  if (filter === 'py-hidden')  pool = listChars.filter(ch => !pyVis(ch));

  // Apply metric band
  const lo = band.min, hi = band.max;

  let eligible;
  if (metric === DRIFT_METRIC_W){
    eligible = pool.filter(ch => {
      const s = driftScoreW(ch);
      return (s >= lo && s <= hi);
    });
  } else if (metric === DRIFT_METRIC_R0W){
    eligible = pool.filter(ch => {
      const r = driftScoreR(ch);
      if (r !== 0) return false;
      const w = driftScoreW(ch);
      return (w >= lo && w <= hi);
    });
  } else {
    eligible = pool.filter(ch => {
      const s = driftScoreT(ch);
      return (s >= lo && s <= hi);
    });
  }

  return {
    listCount: listChars.length,
    eligibleCount: eligible.length,
    eligibleChars: eligible
  };
}

/* =========================
   UI <-> settings.drift (incl. dynamic metric + band)
   ========================= */
function driftApplyPrefsToUI(){
  const p = (settings.drift ||= {...DRIFT_DEFAULTS});

  // Ensure new keys exist (migration)
  if (typeof p.metric !== 'string') p.metric = DRIFT_DEFAULTS.metric;
  if (!Number.isFinite(p.tThreshold)) p.tThreshold = DRIFT_DEFAULTS.tThreshold;
  if (!Number.isFinite(p.wThreshold)) p.wThreshold = DRIFT_DEFAULTS.wThreshold;
  if (!Number.isFinite(p.tMin)) p.tMin = Math.min(p.tThreshold ?? DRIFT_DEFAULTS.tThreshold, -3);
  if (!Number.isFinite(p.tMax)) p.tMax = Math.max(p.tThreshold ?? DRIFT_DEFAULTS.tMax, 1);
  if (!Number.isFinite(p.wMin)) p.wMin = 0;
  if (!Number.isFinite(p.wMax)) p.wMax = Math.max(2, p.wThreshold ?? DRIFT_DEFAULTS.wMax);
  if (!Number.isFinite(p.w0Min)) p.w0Min = DRIFT_DEFAULTS.w0Min;
  if (!Number.isFinite(p.w0Max)) p.w0Max = DRIFT_DEFAULTS.w0Max;

  // Inject metric + band controls (or capture if present)
  driftEnsureMetricControls();

  // Max on screen (display value too)
  if (driftMax) { 
    const v = p.maxOnScreen ?? DRIFT_DEFAULTS.maxOnScreen;
    driftMax.value = String(v);
    if (driftMaxVal) driftMaxVal.textContent = String(v);
  }

  // Filter radios
  const f = (p.filter || 'all');
  if (driftFilterAll)        driftFilterAll.checked       = (f === 'all');
  if (driftFilterPyVisible)  driftFilterPyVisible.checked = (f === 'py-visible');
  if (driftFilterPyHidden)   driftFilterPyHidden.checked  = (f === 'py-hidden');

  // Metric radios
  if (driftMetricT)   driftMetricT.checked   = (p.metric === DRIFT_METRIC_T);
  if (driftMetricW)   driftMetricW.checked   = (p.metric === DRIFT_METRIC_W);
  if (driftMetricR0W) driftMetricR0W.checked = (p.metric === DRIFT_METRIC_R0W);

  driftUpdateMetricHelp(p.metric);
  driftConfigureBandUI(p.metric);

  // Sliders under the stage
  if (driftSpeed){
    const s = driftClampNum(p.speedScale ?? DRIFT_DEFAULTS.speedScale, 1, 4, DRIFT_DEFAULTS.speedScale);
    driftSpeed.value = String(s);
    if (driftSpeedVal) driftSpeedVal.textContent = s.toFixed(1) + '×';
  }
  if (driftDotSize){
    const d = driftClampNum(p.dotSize ?? DRIFT_DEFAULTS.dotSize, 28, 96, DRIFT_DEFAULTS.dotSize);
    driftDotSize.value = String(d);
    if (driftDotSizeVal) driftDotSizeVal.textContent = d + 'px';
  }
  if (driftFontSize){
    const fs = driftClampNum(p.charSize ?? DRIFT_DEFAULTS.charSize, 16, 64, DRIFT_DEFAULTS.charSize);
    driftFontSize.value = String(fs);
    if (driftFontSizeVal) driftFontSizeVal.textContent = fs + 'px';
  }
}

function driftSavePrefsFromUI(){
  const metric = driftGetMetric();

  const currMin = parseInt(driftCutMin?.value ?? '', 10);
  const currMax = parseInt(driftCutMax?.value ?? '', 10);
  const minOK = Number.isFinite(currMin);
  const maxOK = Number.isFinite(currMax);

  const next = {
    ...settings.drift,
    // *** 3..20 clamp, not 5..20 ***
    maxOnScreen: Math.max(3, Math.min(20, parseInt(driftMax?.value || String(DRIFT_DEFAULTS.maxOnScreen), 10))),
    filter:      (driftFilterPyVisible?.checked ? 'py-visible'
                  : driftFilterPyHidden?.checked ? 'py-hidden'
                  : 'all'),
    metric: (metric === DRIFT_METRIC_W ? DRIFT_METRIC_W : metric === DRIFT_METRIC_R0W ? DRIFT_METRIC_R0W : DRIFT_METRIC_T),
    speedScale:  driftClampNum(driftSpeed?.value ?? DRIFT_DEFAULTS.speedScale, 0.5, 4, DRIFT_DEFAULTS.speedScale),
    dotSize:     driftClampNum(driftDotSize?.value ?? DRIFT_DEFAULTS.dotSize, 28, 96, DRIFT_DEFAULTS.dotSize),
    charSize:    driftClampNum(driftFontSize?.value ?? DRIFT_DEFAULTS.charSize, 16, 64, DRIFT_DEFAULTS.charSize)
  };

  if (metric === DRIFT_METRIC_W){
    const dom = driftComputeWDomain();
    const lo = minOK ? driftClampNum(currMin, dom.min, dom.max, DRIFT_DEFAULTS.wMin) : (settings.drift?.wMin ?? DRIFT_DEFAULTS.wMin);
    const hi = maxOK ? driftClampNum(currMax, dom.min, dom.max, DRIFT_DEFAULTS.wMax) : (settings.drift?.wMax ?? DRIFT_DEFAULTS.wMax);
    next.wMin = Math.min(lo, hi);
    next.wMax = Math.max(lo, hi);
    if (!Number.isFinite(next.tMin))  next.tMin  = DRIFT_DEFAULTS.tMin;
    if (!Number.isFinite(next.tMax))  next.tMax  = DRIFT_DEFAULTS.tMax;
    if (!Number.isFinite(next.w0Min)) next.w0Min = DRIFT_DEFAULTS.w0Min;
    if (!Number.isFinite(next.w0Max)) next.w0Max = DRIFT_DEFAULTS.w0Max;
  } else if (metric === DRIFT_METRIC_R0W){
    const dom = driftComputeW0Domain();
    const lo = minOK ? driftClampNum(currMin, dom.min, dom.max, DRIFT_DEFAULTS.w0Min)
                     : (settings.drift?.w0Min ?? DRIFT_DEFAULTS.w0Min);
    const hi = maxOK ? driftClampNum(currMax, dom.min, dom.max, DRIFT_DEFAULTS.w0Max)
                     : (settings.drift?.w0Max ?? DRIFT_DEFAULTS.w0Max);
    next.w0Min = Math.min(lo, hi);
    next.w0Max = Math.max(lo, hi);
    if (!Number.isFinite(next.tMin)) next.tMin = DRIFT_DEFAULTS.tMin;
    if (!Number.isFinite(next.tMax)) next.tMax = DRIFT_DEFAULTS.tMax;
    if (!Number.isFinite(next.wMin)) next.wMin = DRIFT_DEFAULTS.wMin;
    if (!Number.isFinite(next.wMax)) next.wMax = DRIFT_DEFAULTS.wMax;
  } else {
    const dom = driftComputeTDomain();
    const lo = minOK ? driftClampNum(currMin, dom.min, dom.max, DRIFT_DEFAULTS.tMin)
                     : (settings.drift?.tMin ?? DRIFT_DEFAULTS.tMin);
    const hi = maxOK ? driftClampNum(currMax, dom.min, dom.max, DRIFT_DEFAULTS.tMax)
                     : (settings.drift?.tMax ?? DRIFT_DEFAULTS.tMax);
    next.tMin = Math.min(lo, hi);
    next.tMax = Math.max(lo, hi);
    if (!Number.isFinite(next.wMin))  next.wMin  = DRIFT_DEFAULTS.wMin;
    if (!Number.isFinite(next.wMax))  next.wMax  = DRIFT_DEFAULTS.wMax;
    if (!Number.isFinite(next.w0Min)) next.w0Min = DRIFT_DEFAULTS.w0Min;
    if (!Number.isFinite(next.w0Max)) next.w0Max = DRIFT_DEFAULTS.w0Max;
  }

  settings.drift = next;
  if (typeof window.saveSettings === 'function') saveSettings();
}

function driftUpdatePreview(){
  // Recompute band bounds when filter/metric changes (adaptive domains)
  driftConfigureBandUI(driftGetMetric());

  const snap = driftComputeEligible();
  if (driftDueCount)  driftDueCount.textContent = String(snap.listCount);
  if (driftIncluded)  driftIncluded.innerHTML   =
    `With these settings, <strong>${snap.eligibleCount}</strong> characters will be included in the game.`;
  if (driftStartBtn) driftStartBtn.disabled = (snap.eligibleCount === 0);
}

/* =========================
   ENTRY lifecycle
   ========================= */
function mhOpenDriftEntry(){
  if (typeof window.closeListModal === 'function') closeListModal();

  driftApplyPrefsToUI();
  driftApplyDynamicPrefsFromSettings();
  driftUpdatePreview();

  if (driftPlay)  driftPlay.classList.add('hidden');
  if (driftEntry) driftEntry.classList.remove('hidden');

  if (driftOverlay){
    driftOverlay.classList.add('open');
    driftOverlay.setAttribute('aria-hidden','false');
  }
  document.documentElement.classList.add('no-scroll');
  document.body.classList.add('no-scroll');
}
function mhCloseDrift(){
  // Stop & reset play if running
  driftStopAnim();
  driftStage && (driftStage.innerHTML = '');
  driftNodes = [];
  driftBacklog = [];
  driftHideMiniCard();
  driftEndPanel && driftEndPanel.classList.add('hidden');

  if (driftOverlay){
    driftOverlay.classList.remove('open');
    driftOverlay.setAttribute('aria-hidden','true');
  }
  document.documentElement.classList.remove('no-scroll');
  document.body.classList.remove('no-scroll');

  try {
    if (window._mhReopenListAfterDrift && typeof window.openListModal === 'function'){
      window._mhReopenListAfterDrift = false;
      setTimeout(()=> openListModal(), 0);
    }
  } catch {}
}

/* Wire entry controls (once) */
(function wireDriftEntryControls(){
  if (!driftEntry) return;
  if (driftEntry.dataset.wired === '1') return;
  driftEntry.dataset.wired = '1';

  // Ensure metric + band UI exists before wiring
  driftEnsureMetricControls();

  driftMax?.addEventListener('input', () => {
    const v = Math.max(3, Math.min(20, parseInt(driftMax.value || '7', 10)));
    driftMax.value = String(v);
    if (driftMaxVal) driftMaxVal.textContent = String(v);
    driftSavePrefsFromUI();
  });

  // Legacy single cutoff (kept harmless if present/visible)
  driftT?.addEventListener('input', () => {
    if (driftTVal) driftTVal.textContent = driftT.value;
    driftSavePrefsFromUI();
    driftUpdatePreview();
  });

  // New band sliders
  const onBandInput = (e) => {
    if (driftCutMin && driftCutMax){
      let a = parseInt(driftCutMin.value, 10);
      let b = parseInt(driftCutMax.value, 10);
      if (Number.isFinite(a) && Number.isFinite(b) && a > b){
        if (e && e.target === driftCutMin) driftCutMax.value = String(a);
        else                               driftCutMin.value = String(b);
      }
      if (driftCutMinVal) driftCutMinVal.textContent = String(driftCutMin.value);
      if (driftCutMaxVal) driftCutMaxVal.textContent = String(driftCutMax.value);
    }
    driftSavePrefsFromUI();
    driftUpdatePreview();
  };
  driftCutMin?.addEventListener('input', onBandInput);
  driftCutMax?.addEventListener('input', onBandInput);

  [driftFilterAll, driftFilterPyVisible, driftFilterPyHidden].forEach(r => {
    r?.addEventListener('change', () => {
      driftSavePrefsFromUI();
      driftUpdatePreview();
    });
  });

  // Metric radio handlers
  driftMetricT?.addEventListener('change', () => {
    if (driftMetricT.checked) {
      driftSetMetric(DRIFT_METRIC_T);
      driftSavePrefsFromUI();
    }
  });
  driftMetricW?.addEventListener('change', () => {
    if (driftMetricW.checked) {
      driftSetMetric(DRIFT_METRIC_W);
      driftSavePrefsFromUI();
    }
  });
  driftMetricR0W?.addEventListener('change', () => {
    if (driftMetricR0W.checked) {
      driftSetMetric(DRIFT_METRIC_R0W);
      driftSavePrefsFromUI();
    }
  });

  driftCloseBtn?.addEventListener('click', mhCloseDrift);
  driftCancelBtn?.addEventListener('click', mhCloseDrift);

  // Click backdrop to close only when ENTRY is visible
  driftOverlay?.addEventListener('click', (e) => {
    if (!driftEntry || driftEntry.classList.contains('hidden')) return;
    if (e.target === driftOverlay) mhCloseDrift();
  });

  driftStartBtn?.addEventListener('click', () => {
    driftSavePrefsFromUI();
    driftStartPlay();
  });
})();

/* Public hooks */
window.mhOpenDriftEntry = mhOpenDriftEntry;
function driftInitOnBoot(){
  if (!settings.drift) settings.drift = {...DRIFT_DEFAULTS};

  const p = settings.drift;
  if (typeof p.metric !== 'string') p.metric = DRIFT_METRIC_T;
  if (typeof p.speedScale !== 'number') p.speedScale = DRIFT_DEFAULTS.speedScale;
  if (typeof p.dotSize    !== 'number') p.dotSize    = DRIFT_DEFAULTS.dotSize;
  if (typeof p.charSize   !== 'number') p.charSize   = DRIFT_DEFAULTS.charSize;
  if (!Number.isFinite(p.tThreshold)) p.tThreshold = DRIFT_DEFAULTS.tThreshold;
  if (!Number.isFinite(p.wThreshold)) p.wThreshold = DRIFT_DEFAULTS.wThreshold;
  if (!Number.isFinite(p.tMin)) p.tMin = Math.min(p.tThreshold ?? DRIFT_DEFAULTS.tThreshold, -3);
  if (!Number.isFinite(p.tMax)) p.tMax = Math.max(p.tThreshold ?? DRIFT_DEFAULTS.tMax, 1);
  if (!Number.isFinite(p.wMin)) p.wMin = 0;
  if (!Number.isFinite(p.wMax)) p.wMax = Math.max(2, p.wThreshold ?? DRIFT_DEFAULTS.wMax);
  if (!Number.isFinite(p.w0Min)) p.w0Min = DRIFT_DEFAULTS.w0Min;
  if (!Number.isFinite(p.w0Max)) p.w0Max = DRIFT_DEFAULTS.w0Max;

  if (typeof window.saveSettings === 'function') saveSettings();

  driftEnsureMetricControls();
  driftApplyPrefsToUI();
  driftApplyDynamicPrefsFromSettings();
}
window.driftInitOnBoot  = driftInitOnBoot;

/******************************************************
 * PLAY — stage + physics + mini card
 ******************************************************/
const driftStage    = document.getElementById('driftStage');
const driftEndPanel = document.getElementById('driftEnd');

/* HUD */
const driftCounterEl = document.getElementById('driftCounter') || document.getElementById('counterBadge');

/* Desktop-only shortcuts bar (bottom of stage) */
let driftShortcutsEl = null;
function driftInjectShortcutsStyles(){
  if (document.getElementById('drift-shortcuts-styles')) return;
  const css = `
#driftShortcuts{
  position:absolute; left:50%; transform:translateX(-50%);
  bottom:8px; z-index:4; display:none; gap:8px;
  pointer-events:none;
}
#driftShortcuts .sc{
  pointer-events:auto;
  display:inline-flex; align-items:center; gap:6px;
  padding:6px 10px; border-radius:999px; font-size:12px;
  background: rgba(0,0,0,.08);
  color: var(--text-main, #111);
  border: 1px solid rgba(0,0,0,.12);
  box-shadow: 0 6px 14px rgba(0,0,0,.12);
}
html[data-theme="dark"] #driftShortcuts .sc{
  background: rgba(255,255,255,.08);
  color: var(--text-main, #e9edf1);
  border-color: rgba(255,255,255,.16);
}
@media (hover:hover) and (pointer:fine){
  #driftShortcuts{ display:flex; }
}
`;
  const st = document.createElement('style');
  st.id = 'drift-shortcuts-styles';
  st.textContent = css;
  document.head.appendChild(st);
}
function driftEnsureDesktopShortcuts(){
  if (driftShortcutsEl || !driftStage) return;
  driftInjectShortcutsStyles();
  const el = document.createElement('div');
  el.id = 'driftShortcuts';
  el.innerHTML = `
    <div class="sc"><span class="kbd">w</span><span>= keep</span></div>
    <div class="sc"><span class="kbd">r</span><span>= remove</span></div>
    <div class="sc"><span class="kbd">x</span><span>= exit</span></div>
  `;
  driftStage.appendChild(el);
  driftShortcutsEl = el;
}

/* Play state */
let driftBacklog = [];   // chars waiting to enter play
let driftNodes   = [];   // [{ ch, el, x, y, vx, vy, _colorIdx }]

/* Physics params (dynamic w/ sliders) */
let DRIFT_DOT_SIZE         = DRIFT_DEFAULTS.dotSize;   // px
let DRIFT_FONT_PX          = DRIFT_DEFAULTS.charSize;  // px
let DRIFT_SPEED_SCALE      = DRIFT_DEFAULTS.speedScale; // 1..4
const DRIFT_BASE_MAX_SPEED = 2.0;
let DRIFT_MAX_SPEED        = DRIFT_BASE_MAX_SPEED * DRIFT_SPEED_SCALE;
let DRIFT_BORDER_PUSH      = 0.25 * DRIFT_SPEED_SCALE;
const DRIFT_PAD            = 8;
let DRIFT_REPULSE_DIST     = Math.max(28, Math.round(DRIFT_DOT_SIZE * 1.05));
const DRIFT_REPULSE_K      = 2.115;
let driftRaf = 0;

function driftMeasureDotSize(){ return DRIFT_DOT_SIZE; }

function driftClamp(v, lo, hi){ return v < lo ? lo : (v > hi ? hi : v); }
function driftLen(x,y){ return Math.hypot(x,y); }
function driftGiveInitialImpulse(n){
  const a = Math.random() * Math.PI * 2;
  let sp = (Math.random() * 0.4) + 0.3; // 0.3..0.7 baseline
  sp *= (DRIFT_SPEED_SCALE / 2);         // scale: 2.0 => 1x baseline
  n.vx = Math.cos(a)*sp;
  n.vy = Math.sin(a)*sp;
}
function driftReImpulseAll(){ for (const n of driftNodes) driftGiveInitialImpulse(n); }

/* ===== Mini card (created on demand) ===== */
let miniCard, cHan, cPyTop, cCount, cCn, cPy, cTr, cInline, cReplay, miniBackdrop;
let currentChar = '';
let cardPool = null;          // { type:'sid'|'plain'|'none', items:[...], count }
let cardExIdx = 0;

function driftInjectMiniCardStyles(){
  if (document.getElementById('drift-minicard-styles')) return;
  const css = `
#miniCard.hidden{ display:none; }
#miniCard{
  position: fixed; inset: 0; z-index: 9500;
  display: flex; align-items: center; justify-content: center;
}
#miniCard .backdrop{
  position:absolute; inset:0; background: rgba(0,0,0,.6);
}
#miniCard .card{
  position: relative; z-index:1;
  width:min(92vw, 560px);
  max-height: min(86vh, 640px);
  overflow: auto;
  background: var(--card-bg, #fff);
  color: var(--text-main, #111);
  border: 1px solid rgba(0,0,0,.06);
  border-radius: 12px;
  box-shadow: 0 10px 30px var(--shadow, rgba(0,0,0,.35));
  padding: 16px 16px 12px;
  text-align:center;
}
#miniCard .han{ font-size: 2.4rem; line-height:1.1; cursor:pointer; user-select:none; }
#miniCard .py-top{ font-size: 1.2rem; color: var(--text-sub, #9aa5b1); }
#miniCard .count { font-size:.8rem; color: var(--text-sub, #9aa5b1); margin-top:2px; }
#miniCard .cn   { font-size: 1.1rem; margin-top:8px; display:inline-flex; align-items:center; gap:8px; }
#miniCard .cn .text{ cursor:pointer; }
#miniCard .py, #miniCard .tr { font-size:.95rem; color: var(--text-sub, #9aa5b1); margin-top:2px; cursor:pointer; }
#miniCard .actions{
  position: sticky; bottom: 0;
  display:flex; align-items:center; justify-content:center; gap:12px;
  padding: 10px 12px;
  margin-top: 12px;
  background: linear-gradient(180deg, transparent, color-mix(in srgb, var(--card-bg, #fff) 92%, #000 8%));
  backdrop-filter: blur(2px);
  border-top: 1px solid rgba(0,0,0,.06);
}
html[data-theme="dark"] #miniCard .actions{ border-top-color: rgba(255,255,255,.08); }
#miniCard button{
  border:none; border-radius:8px; padding:8px 12px; cursor:pointer;
}
#miniCard .btn-keep   { background:#e9eef4; color:var(--text-main, #111); }
#miniCard .btn-remove { background:var(--tone1, #f44336); color:#fff; }
#miniCard .btn-replay { background:var(--tone3, #2196F3); color:#fff; }
#miniCard .pleco-inline{
  background:#fcfcfc; color:#0066aa; border:1px solid #ccc; border-radius:6px;
  padding: 4px 10px; font-size:.9rem; cursor:pointer;
}
#miniCard .hl{ color:#2196F3; text-decoration:none; }
`;
  const style = document.createElement('style');
  style.id = 'drift-minicard-styles';
  style.textContent = css;
  document.head.appendChild(style);
}

function driftEnsureMiniCard(){
  if (miniCard) return;

  driftInjectMiniCardStyles();

  miniCard = document.createElement('div');
  miniCard.id = 'miniCard';
  miniCard.className = 'hidden';
  miniCard.setAttribute('aria-hidden','true');
  miniCard.innerHTML = `
<div class="backdrop"></div>
<div class="card" role="dialog" aria-modal="true">
  <div class="corner left">
    <button class="btn-remove" id="cRemoveL" title="I knew (Enter/R)">I knew</button>
    <button class="btn-keep"   id="cKeepL"   title="Again (Esc/W)">Again</button>
  </div>

  <div class="corner right">
    <button class="btn-remove" id="cRemoveR" title="I knew (Enter/R)">I knew</button>
    <button class="btn-keep"   id="cKeepR"   title="Again (Esc/W)">Again</button>
  </div>

  <div class="han" id="cHan" title="Open in Pleco"></div>
  <div class="py-top" id="cPyTop"></div>
  <div class="count" id="cCount"></div>

  <div class="cn">
    <span class="text" id="cCn"></span>
    <button class="pleco-inline" id="cPlecoInline" title="Open sentence in Pleco">P</button>
  </div>

  <div class="py" id="cPy"></div>
  <div class="tr" id="cTr"></div>

  <div class="actions">
    <button class="btn-replay" id="cReplay" title="Replay">🔊</button>
  </div>
</div>
  `;
  document.body.appendChild(miniCard);

  // Hook refs
  miniBackdrop = miniCard.querySelector('.backdrop');
  cHan    = document.getElementById('cHan');
  cPyTop  = document.getElementById('cPyTop');
  cCount  = document.getElementById('cCount');
  cCn     = document.getElementById('cCn');
  cPy     = document.getElementById('cPy');
  cTr     = document.getElementById('cTr');
  cInline = document.getElementById('cPlecoInline');
  cReplay = document.getElementById('cReplay');

  const keepBtns   = [document.getElementById('cKeepL'),   document.getElementById('cKeepR')];
  const removeBtns = [document.getElementById('cRemoveL'), document.getElementById('cRemoveR')];

  cHan.addEventListener('click', ()=> { if (currentChar) driftOpenPleco(currentChar); });
  cInline.addEventListener('click', (e)=>{ e.preventDefault(); e.stopPropagation(); const s = cCn.textContent.trim(); driftOpenPleco(s || currentChar); });

  cCn.addEventListener('click', ()=> { const s = cCn.textContent.trim(); if (s) driftSpeakSentence(s); });

  cReplay.addEventListener('click', ()=> { if (currentChar) driftSpeakChar(currentChar); });

  keepBtns.forEach(btn => btn?.addEventListener('click',   ()=> driftCloseMiniCard('keep')));
  removeBtns.forEach(btn => btn?.addEventListener('click', ()=> driftCloseMiniCard('remove')));

  miniBackdrop.addEventListener('click', ()=> driftCloseMiniCard('keep'));
}

/* Speak helpers */
function driftSpeak(text, rate=1){
  if (!text || !('speechSynthesis' in window)) return;
  try { speechSynthesis.cancel(); } catch {}
  const u = new SpeechSynthesisUtterance(text);
  try {
    u.lang = (window.settings?.lang || 'zh-CN');
    if (window.settings?.sentenceRate) u.rate = window.settings.sentenceRate;
  } catch {}
  try { speechSynthesis.speak(u); } catch {}
}
function driftSpeakSentence(s){ driftSpeak(s, 1.0); }
function driftSpeakChar(ch){ driftSpeak(ch, 1.0); }
function driftOpenPleco(text){
  try { if (typeof window.lookupInPleco === 'function') return lookupInPleco(text); } catch {}
  const q = encodeURIComponent(text || '');
  if (q) location.href = `plecoapi://x-callback-url/s?q=${q}`;
}

/* Highlight helper */
function driftRegEsc(s){ return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
function driftHighlightAll(hay, needle){
  if (!hay || !needle) return hay || '';
  return hay.replace(new RegExp(driftRegEsc(needle), 'g'), '<span class="hl">'+needle+'</span>');
}

/* Example resolution using app globals if present */
function driftNormalizeSid(v){
  const n = typeof v === 'number' ? v : parseInt(v,10);
  return Number.isFinite(n) ? n : null;
}
function driftUniqueNumeric(arr){
  return Array.from(new Set(arr.map(driftNormalizeSid).filter(n => n !== null)));
}
function driftBuildExamplePoolForChar(ch){
  const postings = (window.indexMap && window.indexMap[ch]) || [];
  const sidList = driftUniqueNumeric(postings);
  if (sidList.length){
    return { type:'sid', items: sidList, count: sidList.length };
  }
  const sources = [
    (g)=> g.examplesByChar?.[ch],
    (g)=> g.sentencesByChar?.[ch],
    (g)=> g.sIndex?.[ch],
    (g)=> g.sentenceIndex?.[ch],
    (g)=> g.exIndex?.[ch],
  ];
  for (const pick of sources){
    try {
      const arr = pick(window);
      if (Array.isArray(arr) && arr.length){
        const norm = arr.map(e => ({
          cn: e.cn ?? e.s ?? e.text ?? '',
          py: e.py ?? e.pinyin ?? '',
          tr: e.tr ?? e.en ?? e.translation ?? ''
        })).filter(o => o.cn || o.py || o.tr);
        if (norm.length) return { type:'plain', items:norm, count:norm.length };
      }
    } catch {}
  }
  return { type:'none', items:[], count:0 };
}
function driftResolveExample(ch, pool, idx){
  if (!pool || !pool.items || !pool.items.length) return { cn:'', py:'', tr:'', sid:null };
  if (pool.type === 'sid'){
    const sid = pool.items[idx % pool.items.length];
    const cn  = (window.sentences && window.sentences[sid - 1]) || '';
    const sp  = (window.sentencePinyin && window.sentencePinyin[sid - 1]) || '';
    const tr  = (window.sentenceTranslation && window.sentenceTranslation[sid - 1]) || '';
    return { cn, py: sp || '', tr, sid };
  } else if (pool.type === 'plain'){
    const ex = pool.items[idx % pool.items.length];
    return { cn: ex.cn || '', py: ex.py || '', tr: ex.tr || '', sid: null };
  }
  return { cn:'', py:'', tr:'', sid:null };
}

/* Card open/render/close */
function driftOpenMiniCardForChar(ch){
  driftEnsureMiniCard();
  currentChar = ch;
  cardPool = driftBuildExamplePoolForChar(ch);
  cardExIdx = 0;

  cHan.textContent = ch;
  let charPy = '';
  try { charPy = ((window.pyIndex && window.pyIndex[ch]) || [])[0]?.py || ''; } catch {}
  cPyTop.textContent = charPy || '';
  cCount.textContent = (cardPool?.items?.length || 0) + (cardPool?.items?.length === 1 ? ' sentence' : ' sentences');

  driftRenderMiniCardBody();

  miniCard.classList.remove('hidden');
  miniCard.setAttribute('aria-hidden','false');
  try { cReplay.focus({preventScroll:true}); } catch {}

  driftSpeakChar(ch);

  const openedIdx = 0;
  setTimeout(() => {
    if (currentChar !== ch) return;
    if (cardExIdx !== openedIdx) return;
    const s = (cCn?.textContent || '').trim();
    if (s && s.length <= DRIFT_AUTO_SENTENCE_MAXLEN) driftSpeakSentence(s);
  }, DRIFT_AUTO_SENTENCE_DELAY_MS);
}

function driftRenderMiniCardBody(){
  const ex = driftResolveExample(currentChar, cardPool, cardExIdx);
  cCn.innerHTML = ex.cn ? driftHighlightAll(ex.cn, currentChar) : '';
  cPy.textContent = ex.py || '';
  cTr.textContent = ex.tr || '';
  const cnWrap = cCn.parentElement;
  Object.assign(cnWrap.style, { display:'flex', justifyContent:'center', alignItems:'baseline', gap:'8px', width:'100%' });
  cCn.style.textAlign = 'center';

  const n = cardPool?.items?.length || 0;
  const cycle = ()=> {
    if (n > 1){
      cardExIdx = (cardExIdx + 1) % n;
      driftRenderMiniCardBody();
    }
  };
  cPy.onclick = cycle;
  cTr.onclick = cycle;
  cCount.textContent = n + (n === 1 ? ' sentence' : ' sentences');
}
function driftCloseMiniCard(mode /* 'keep' | 'remove' */){
  const ch = currentChar;
  miniCard.classList.add('hidden');
  miniCard.setAttribute('aria-hidden','true');

  if (mode === 'remove' && ch){
    driftRemoveChar(ch);
    driftCheckEndState();
  } else {
    driftReImpulseAll();
  }
  currentChar = '';
}

/* HUD updates */
function driftUpdateCounter(){
  if (!driftCounterEl) return;
  const onStage = driftNodes?.length || 0;
  const waiting = driftBacklog?.length || 0;
  driftCounterEl.textContent = String(onStage + waiting);
}

/* ===== Theme-aware palettes ===== */
function driftIsDarkTheme(){
  const attr = document.documentElement.getAttribute('data-theme');
  if (attr === 'dark')  return true;
  if (attr === 'light') return false;
  return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
}
const DRIFT_FIRST3_LIGHT = ['#1E88E5', '#E53935', '#43A047'];
const DRIFT_PALETTE_LIGHT = [
  '#FB8C00', '#8E24AA', '#00ACC1', '#5E35B1', '#7CB342',
  '#F4511E', '#3949AB', '#C2185B', '#00897B', '#D32F2F',
  '#039BE5', '#2E7D32', '#FF7043', '#9E9D24', '#546E7A',
  '#455A64', '#8D6E63'
];
const DRIFT_FIRST3_DARK = ['#0A84FF', '#FF453A', '#30D158'];
const DRIFT_PALETTE_DARK = [
  '#FB8C00', '#8E24AA', '#00ACC1', '#F4511E', '#C2185B',
  '#3949AB', '#2E7D32', '#D32F2F', '#039BE5', '#7CB342',
  '#5E35B1', '#00897B', '#FF7043', '#9E9D24'
];

function driftFirst3(){ return driftIsDarkTheme() ? DRIFT_FIRST3_DARK : DRIFT_FIRST3_LIGHT; }
function driftRestPalette(){ return driftIsDarkTheme() ? DRIFT_PALETTE_DARK : DRIFT_PALETTE_LIGHT; }

function driftColorFromAbsoluteIndex(absIdx){
  const first = driftFirst3();
  const pal   = driftRestPalette();
  if (absIdx < first.length) return first[absIdx];
  const idx = (absIdx - first.length) % pal.length;
  return pal[idx];
}

/* keep a simple running index so adjacent nodes are different */
let driftColorCursor = 0;

function driftRecolorAllNodes(){
  for (const n of driftNodes){
    const han = n.el.querySelector('.han');
    if (!han) continue;
    han.style.color = driftColorFromAbsoluteIndex(n._colorIdx || 0);
  }
}

/* Watch for explicit data-theme changes */
try{
  const _mo = new MutationObserver(muts=>{
    for (const m of muts){
      if (m.type === 'attributes' && m.attributeName === 'data-theme'){
        driftRecolorAllNodes();
        break;
      }
    }
  });
  _mo.observe(document.documentElement, { attributes:true });
} catch {}

/* Watch OS theme flips if app isn’t forcing data-theme */
try{
  const mql = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)');
  if (mql) mql.addEventListener('change', ()=>{
    const attr = document.documentElement.getAttribute('data-theme');
    if (!attr) driftRecolorAllNodes();
  });
} catch {}

/* =========================
   Stage nodes
   ========================= */
function driftCreateNode(ch){
  const el = document.createElement('div');
  el.className = 'dot';

  const colorIdx  = driftColorCursor++;
  const charColor = driftColorFromAbsoluteIndex(colorIdx);

  el.innerHTML = `<div class="han"
                    style="
                      width:${DRIFT_DOT_SIZE}px;height:${DRIFT_DOT_SIZE}px;
                      display:grid;place-items:center;border-radius:9999px;
                      background: var(--drift-bubble-bg, rgba(0,0,0,.06));
                      border: 1px solid var(--drift-bubble-border, rgba(0,0,0,.12));
                      color:${charColor};
                      font-size:${DRIFT_FONT_PX}px; line-height:1;
                    ">
                    ${ch}
                  </div>`;

  const node = { ch, el, x:0, y:0, vx:0, vy:0, _colorIdx: colorIdx };

  el.addEventListener('click', (e)=>{
    e.stopPropagation();
    driftOpenMiniCardForChar(ch);
  });

  let pressT = null, pressed = false;
  const startPress = ()=>{
    if (pressed) return;
    pressed = true;
    pressT = setTimeout(()=> driftOpenMiniCardForChar(ch), 350);
  };
  const endPress = ()=>{ pressed = false; clearTimeout(pressT); };
  el.addEventListener('touchstart', startPress, {passive:true});
  el.addEventListener('touchend', endPress, {passive:true});
  el.addEventListener('touchcancel', endPress, {passive:true});

  return node;
}

function driftPlaceRandom(node){
  const W = driftStage.clientWidth;
  const H = driftStage.clientHeight;
  const size = DRIFT_DOT_SIZE;
  const pad  = DRIFT_PAD;
  const margin = size/2 + pad;

  const x = Math.max(margin, Math.floor(Math.random()*(Math.max(1, W - size - pad*2))) + size/2);
  const y = Math.max(margin, Math.floor(Math.random()*(Math.max(1, H - size - pad*2))) + size/2);

  node.x = x; node.y = y;
  node.el.style.transform = `translate(${x - size/2}px, ${y - size/2}px)`;
}
function driftRefillStage(){
  // *** 3..20 clamp here as well ***
  const max = Math.max(3, Math.min(20, settings.drift?.maxOnScreen || DRIFT_DEFAULTS.maxOnScreen));
  while (driftNodes.length < max){
    const ch = driftBacklog.shift();
    if (!ch) break;
    const node = driftCreateNode(ch);
    driftStage.appendChild(node.el);
    driftPlaceRandom(node);
    driftGiveInitialImpulse(node);
    driftNodes.push(node);
  }
  if (!driftNodes.length && !driftBacklog.length){
    driftEndPanel?.classList.remove('hidden');
  } else {
    driftEndPanel?.classList.add('hidden');
  }

  driftUpdateCounter();
}
function driftRemoveChar(ch){
  const i = driftNodes.findIndex(n => n.ch === ch);
  if (i !== -1){
    const n = driftNodes[i];
    if (n.el && n.el.parentNode) n.el.parentNode.removeChild(n.el);
    driftNodes.splice(i, 1);
  }
  driftRefillStage();
  driftUpdateCounter();
}
function driftCheckEndState(){
  if (!driftNodes.length && !driftBacklog.length){
    driftEndPanel?.classList.remove('hidden');
  }
}

/* =========================
   Play lifecycle
   ========================= */
function driftStartPlay(){
  const snap = driftComputeEligible();
  if (!snap.eligibleChars.length) return;

  driftColorCursor = 0;

  driftBacklog = snap.eligibleChars.slice();
  driftNodes = [];

  driftStage.innerHTML = '';
  driftEntry?.classList.add('hidden');
  driftPlay?.classList.remove('hidden');

  driftEnsureDesktopShortcuts();

  DRIFT_DOT_SIZE = driftMeasureDotSize();
  driftRefillStage();
  driftStartAnim();
}

function driftExitToEntry(){
  driftStopAnim();
  driftStage.innerHTML = '';
  driftNodes = [];
  driftBacklog = [];
  driftEndPanel?.classList.add('hidden');

  driftHideMiniCard();

  driftPlay?.classList.add('hidden');
  driftEntry?.classList.remove('hidden');

  driftUpdateCounter();
}

/* Anim loop */
function driftStep(){
  const W = driftStage.clientWidth;
  const H = driftStage.clientHeight;

  for (let i=0;i<driftNodes.length;i++){
    for (let j=i+1;j<driftNodes.length;j++){
      const A = driftNodes[i], B = driftNodes[j];
      const dx = A.x - B.x, dy = A.y - B.y;
      const d  = Math.hypot(dx,dy) || 0.0001;
      if (d < DRIFT_REPULSE_DIST){
        const f = (DRIFT_REPULSE_DIST - d) * DRIFT_REPULSE_K / d;
        const fx = dx * f, fy = dy * f;
        A.vx += fx; A.vy += fy;
        B.vx -= fx; B.vy -= fy;
      }
    }
  }

  const margin = (DRIFT_DOT_SIZE/2) + DRIFT_PAD;

  for (const n of driftNodes){
    const s = driftLen(n.vx, n.vy);
    if (s > DRIFT_MAX_SPEED){
      n.vx = (n.vx / s) * DRIFT_MAX_SPEED;
      n.vy = (n.vy / s) * DRIFT_MAX_SPEED;
    }
    n.x += n.vx;
    n.y += n.vy;

    if (n.x < margin) n.vx += DRIFT_BORDER_PUSH;
    if (n.x > W - margin) n.vx -= DRIFT_BORDER_PUSH;
    if (n.y < margin) n.vy += DRIFT_BORDER_PUSH;
    if (n.y > H - margin) n.vy -= DRIFT_BORDER_PUSH;

    n.x = driftClamp(n.x, margin, W - margin);
    n.y = driftClamp(n.y, margin, H - margin);
    n.el.style.transform = `translate(${n.x - DRIFT_DOT_SIZE/2}px, ${n.y - DRIFT_DOT_SIZE/2}px)`;
  }

  driftRaf = requestAnimationFrame(driftStep);
}
function driftStartAnim(){
  DRIFT_DOT_SIZE = driftMeasureDotSize();
  cancelAnimationFrame(driftRaf);
  driftRaf = requestAnimationFrame(driftStep);
}
function driftStopAnim(){
  cancelAnimationFrame(driftRaf);
  driftRaf = 0;
}

/* Buttons */
driftExitBtn?.addEventListener('click', driftExitToEntry);
driftEndBackBtn?.addEventListener('click', driftExitToEntry);
driftShuffleBtn?.addEventListener('click', () => { driftReImpulseAll(); });

/* Resize / Visibility */
window.addEventListener('resize', () => { DRIFT_DOT_SIZE = driftMeasureDotSize(); });
document.addEventListener('visibilitychange', ()=> {
  if (document.hidden){
    driftStopAnim();
  } else if (driftOverlay?.classList.contains('open') && driftPlay && !driftPlay.classList.contains('hidden') && driftNodes.length){
    DRIFT_DOT_SIZE = driftMeasureDotSize();
    driftStartAnim();
  }
});

/* =========================
   Keyboard shortcuts
   ========================= */
document.addEventListener('keydown', (e)=>{
  if (!driftOverlay || !driftOverlay.classList.contains('open')) return;

  const key = e.key.toLowerCase();
  const entryVisible = driftEntry && !driftEntry.classList.contains('hidden');
  const cardOpen = !!miniCard && !miniCard.classList.contains('hidden');

  // ESC on Entry screen closes the Drift window
  if (entryVisible && key === 'escape'){
    e.preventDefault();
    mhCloseDrift();
    return;
  }

  // 'x' exits to Entry from anywhere in overlay
  if (key === 'x'){
    e.preventDefault();
    driftExitToEntry();
    return;
  }

  if (!cardOpen) return;

  // Esc / W → KEEP
  if (key === 'escape' || key === 'w'){
    e.preventDefault();
    driftCloseMiniCard('keep');
  }
  // Enter / R → REMOVE
  else if (key === 'enter' || key === 'r'){
    e.preventDefault();
    driftCloseMiniCard('remove');
  }
});

/* =========================
   Dynamic slider application
   ========================= */
function driftSetSpeedScale(scale){
  DRIFT_SPEED_SCALE = driftClampNum(scale, 1, 4, DRIFT_DEFAULTS.speedScale);
  DRIFT_MAX_SPEED   = DRIFT_BASE_MAX_SPEED * DRIFT_SPEED_SCALE;
  DRIFT_BORDER_PUSH = 0.25 * DRIFT_SPEED_SCALE;
  if (driftSpeedVal) driftSpeedVal.textContent = DRIFT_SPEED_SCALE.toFixed(1) + '×';
}

function driftRelayoutNodesAfterSizeChange(){
  const size = DRIFT_DOT_SIZE;
  const margin = (size/2) + DRIFT_PAD;
  const W = driftStage.clientWidth;
  const H = driftStage.clientHeight;

  for (const n of driftNodes){
    const han = n.el.querySelector('.han');
    if (han){
      han.style.width = size + 'px';
      han.style.height = size + 'px';
    }
    n.x = driftClamp(n.x, margin, Math.max(margin, W - margin));
    n.y = driftClamp(n.y, margin, Math.max(margin, H - margin));
    n.el.style.transform = `translate(${n.x - size/2}px, ${n.y - size/2}px)`;
  }
}

function driftSetDotSize(px){
  const d = driftClampNum(px, 28, 96, DRIFT_DEFAULTS.dotSize);
  DRIFT_DOT_SIZE = d;
  DRIFT_REPULSE_DIST = Math.max(28, Math.round(DRIFT_DOT_SIZE * 1.05));
  if (driftDotSizeVal) driftDotSizeVal.textContent = d + 'px';
  driftRelayoutNodesAfterSizeChange();
}

function driftSetCharFontSize(px){
  const fs = driftClampNum(px, 16, 64, DRIFT_DEFAULTS.charSize);
  DRIFT_FONT_PX = fs;
  if (driftFontSizeVal) driftFontSizeVal.textContent = fs + 'px';
  for (const n of driftNodes){
    const han = n.el.querySelector('.han');
    if (han) han.style.fontSize = fs + 'px';
  }
}

/* Apply from settings (on entry open / boot) */
function driftApplyDynamicPrefsFromSettings(){
  const prefs = settings.drift || DRIFT_DEFAULTS;
  driftSetSpeedScale(prefs.speedScale ?? DRIFT_DEFAULTS.speedScale);
  driftSetDotSize(prefs.dotSize ?? DRIFT_DEFAULTS.dotSize);
  driftSetCharFontSize(prefs.charSize ?? DRIFT_DEFAULTS.charSize);
}

/* Wire slider events */
(function wireDriftSliders(){
  if (driftSpeed){
    driftSpeed.addEventListener('input', ()=>{
      driftSetSpeedScale(parseFloat(driftSpeed.value));
      driftSavePrefsFromUI();
    });
  }
  if (driftDotSize){
    driftDotSize.addEventListener('input', ()=>{
      driftSetDotSize(parseInt(driftDotSize.value, 10));
      driftSavePrefsFromUI();
    });
  }
  if (driftFontSize){
    driftFontSize.addEventListener('input', ()=>{
      driftSetCharFontSize(parseInt(driftFontSize.value, 10));
      driftSavePrefsFromUI();
    });
  }
})();

/* Helpers */
function driftHideMiniCard(){
  if (!miniCard) return;
  miniCard.classList.add('hidden');
  miniCard.setAttribute('aria-hidden','true');
  currentChar = '';
}

/* Expose public API (again, at end for safety) */
window.mhOpenDriftEntry = mhOpenDriftEntry;
window.driftInitOnBoot  = driftInitOnBoot;

/* Mark loader tag as loaded (optional) */
try {
  const s = document.currentScript;
  if (s) s.dataset.loaded = '1';
} catch {}
