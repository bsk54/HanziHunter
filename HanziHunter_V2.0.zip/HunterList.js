/**********************
 * LIST MODAL (Rankings-style)
 * Rows: rank • [P?] • hanzi • pinyin • next due • level • (t,r,w)
 **********************/

const idleListBtn = document.getElementById('idleListBtn');
const listOverlay = document.getElementById('listOverlay');
const listClose   = document.getElementById('listClose');
const listContent = document.getElementById('listContent');

let sortBtn;      // Sort toggle button (we keep this!)
/* no driftBtn anymore — we now use the centered #listDriftCTA from your HTML */

/* -------- global state -------- */
// Sort modes:
// 0: Score (t = r - w, lowest first)
// 1: Number (original order)
// 2: Due time (earliest first)
// 3: Level (lowest first)
// 4: Unseen cards (by Number)
const SORT_KEY = 'MH_List_Sort';
let currentSortMethod = Number(localStorage.getItem(SORT_KEY));
if (!Number.isInteger(currentSortMethod) || currentSortMethod < 0 || currentSortMethod > 4) {
  currentSortMethod = 0; // default = Score
}
let keysWired = false;

/* --- Pinyin visibility (persisted per selection: dataset+collection+range) --- */
let pinyinDefaultVisible = true;           // default for current selection
let pinyinOverrides = new Map();           // char -> boolean

// Storage key prefix (versioned)
const PHIDE_PREFIX = 'MH_PHIDE_v1';

/* --- Long-press state --- */
const LONG_PRESS_MS = 550;
let longPressTimer = null;
let longPressFired = false;
let suppressClicksUntil = 0;

/* --- List font size (persistent) --- */
const LIST_FONT_KEY = 'MH_List_FontPx_V1';
const LIST_FONT_MIN = 14;
const LIST_FONT_MAX = 36;
let listFontPx = clampNum(Number(localStorage.getItem(LIST_FONT_KEY)) || 18, LIST_FONT_MIN, LIST_FONT_MAX);
let listFontSlider = null; // wired to #listFontRange from your HTML

/* --- Sentence auto-pronounce config (aligned with Drift) --- */
const SENTENCE_DELAY_MS  = 1000;  // speak sentence 1s after the character
const SENTENCE_MAX_CHARS = 10;    // only if sentence length ≤ 10

/* -------- environment helpers -------- */
const isMobileTouch = matchMedia('(hover: none), (pointer: coarse)').matches;
const hasPointer = 'PointerEvent' in window;

/* Create the custom scrollbar if missing */
function ensureListScrollbar(){
  if (document.getElementById('listScrollbar')) return;
  const bar = document.createElement('div');
  bar.id = 'listScrollbar';
  Object.assign(bar.style, {
    position: 'fixed',
    width: '28px',
    background: 'transparent',
    borderRadius: '6px',
    opacity: '0',
    transition: 'opacity .18s ease',
    pointerEvents: 'none',
    zIndex: '4600'
  });
  const thumb = document.createElement('div');
  thumb.className = 'thumb';
  Object.assign(thumb.style, {
    position: 'absolute',
    left: '8px',
    right: '8px',
    borderRadius: '6px',
    background: 'rgba(33,150,243,0.15)',
    boxShadow: '0 1px 4px rgba(0,0,0,.15)',
    height: '40px',
    top: '0'
  });
  bar.appendChild(thumb);
  document.body.appendChild(bar);
}
function getBar()   { return document.getElementById('listScrollbar'); }
function getThumb() { return getBar()?.querySelector('.thumb'); }
function showBar(){ const b=getBar(); if(b){ b.style.opacity='1'; b.style.pointerEvents='auto'; } }
function hideBar(){ const b=getBar(); if(b){ b.style.opacity='0'; b.style.pointerEvents='none'; } }

/**********************
 * Top area: Sort button row (injected) • font slider row (from HTML)
 * We place the sort row ABOVE the centered Hanzi Drift CTA.
 **********************/
function labelForSortMethod(m){
  switch(m){
    case 0: return '1. Sorted by Score';
    case 1: return '2. Sorted by Number';
    case 2: return '3. Sorted by Due time';
    case 3: return '4. Sorted by Level';
    case 4: return '5. Unseen cards (by number)';
    default: return 'Sorted by Score';
  }
}

function isDarkMode(){
  try { if (typeof settings === 'object' && settings && 'dark' in settings) return !!settings.dark; } catch(_){}
  return document.documentElement.classList.contains('dark')
      || document.body.classList.contains('dark')
      || window.matchMedia('(prefers-color-scheme: dark)').matches;
}

function applySortBtnTheme(){
  const dark = isDarkMode();
  const styleBtn = (b) => {
    if (!b) return;
    if (dark){
      Object.assign(b.style, {
        color: '#fff',
        background: 'rgba(255,255,255,0.08)',
        border: '1px solid rgba(255,255,255,0.35)'
      });
    } else {
      Object.assign(b.style, {
        color: '#111',
        background: 'rgba(0,0,0,0.04)',
        border: '1px solid rgba(0,0,0,0.2)'
      });
    }
  };
  styleBtn(sortBtn);
}

function ensureTopBar(){
  if (!listOverlay) return;

  // Wire the HTML-provided font-size slider row
  listFontSlider = document.getElementById('listFontRange');
  const valEl    = document.getElementById('listFontVal');
  if (listFontSlider){
    listFontSlider.min   = String(LIST_FONT_MIN);
    listFontSlider.max   = String(LIST_FONT_MAX);
    listFontSlider.step  = '1';
    listFontSlider.value = String(listFontPx);
    listFontSlider.addEventListener('input', ()=>{
      listFontPx = clampNum(Number(listFontSlider.value) || 18, LIST_FONT_MIN, LIST_FONT_MAX);
      try { localStorage.setItem(LIST_FONT_KEY, String(listFontPx)); } catch(_){}
      if (valEl) valEl.textContent = String(listFontPx) + 'px';
      applyListFontSize();
    });
    if (valEl) valEl.textContent = String(listFontPx) + 'px';
  }

  // Inject a tiny top bar with ONLY the Sort button.
  if (!document.getElementById('listTopBar')){
    const modalBox = listOverlay.querySelector('.modal') || listOverlay; // fallback
    const topBar = document.createElement('div');
    topBar.id = 'listTopBar';
    Object.assign(topBar.style, {
      display:'flex',
      alignItems:'center',
      justifyContent:'flex-start',
      gap:'10px',
      padding:'4px 0 0 0',
      flexWrap:'wrap'
    });

    // Sort button
    sortBtn = document.createElement('button');
    sortBtn.id = 'listOrderBtn';
    sortBtn.type = 'button';
    sortBtn.title = 'Toggle order (w)';
    sortBtn.textContent = labelForSortMethod(currentSortMethod);
    Object.assign(sortBtn.style, {
      borderRadius:'8px',
      padding:'6px 10px',
      fontSize:'13px',
      cursor:'pointer',
      marginTop:'15px'
    });
    sortBtn.addEventListener('click', ()=> { toggleSortMethod(); renderListModal(); });

    topBar.appendChild(sortBtn);

    // Insert ABOVE the centered Hanzi Drift CTA (if present), else before listContent
    const ctaWrap = document.getElementById('listDriftCTAWrap');
    if (ctaWrap && ctaWrap.parentNode){
      ctaWrap.parentNode.insertBefore(topBar, ctaWrap);
    } else {
      modalBox.insertBefore(topBar, listContent);
    }

    applySortBtnTheme();

    // Make the close button a floating “×” (unchanged from your prior style)
    if (listClose){
      listClose.textContent = '×';
      Object.assign(listClose.style, {
        position:'absolute',
        top:'8px',
        right:'8px',
        width:'33px',
        height:'33px',
        borderRadius:'50%',
        background:'var(--tone2, #FFC107)',
        color:'#fff',
        border:'none',
        display:'flex',
        alignItems:'center',
        justifyContent:'center',
        fontSize:'16px',
        fontWeight:'200',
        lineHeight:'1',
        cursor:'pointer',
        zIndex:'5',
        boxShadow:'0 2px 8px rgba(0,0,0,.25)'
      });
    }
  } else {
    // Already present: restore handles
    sortBtn  = document.getElementById('listOrderBtn');
    if (sortBtn) sortBtn.textContent = labelForSortMethod(currentSortMethod);
    applySortBtnTheme();

    // restore font slider ui
    listFontSlider = document.getElementById('listFontRange');
    if (listFontSlider) listFontSlider.value = String(listFontPx);
    const v = document.getElementById('listFontVal');
    if (v) v.textContent = String(listFontPx) + 'px';
  }
}

/**********************
 * Selection identity & PHide persistence (with forward migration)
 **********************/
function currentDatasetId(){
  return (window.settings && window.settings.datasetId) || (window.datasetSelect && datasetSelect.value) || '01';
}
function currentCollectionId(){
  if (typeof getActiveCollectionId === 'function') return getActiveCollectionId();
  return (window.settings && window.settings.activeCollectionId) || 'default';
}
function currentRange(){
  const s = window.settings || {};
  const r = s.range || {};
  const min = Math.max(1, Number(r.min) || 1);
  const max = Math.max(min, Number(r.max) || (Array.isArray(window.chars) ? window.chars.length : min));
  return { min, max };
}
function buildPHideKey(ds, col, min, max){
  return `${PHIDE_PREFIX}:${ds}:${col}:${min}-${max}`;
}

function savePHide(){
  const {min, max} = currentRange();
  const ds = String(currentDatasetId());
  const col = String(currentCollectionId());
  const key = buildPHideKey(ds, col, min, max);
  const obj = {
    default: !!pinyinDefaultVisible,
    overrides: Object.fromEntries(pinyinOverrides) // { ch: bool, ... }
  };
  try { localStorage.setItem(key, JSON.stringify(obj)); } catch(_){}
}

function tryMigratePHideForward(ds, col, curMin, curMax){
  // If no record exists for cur range, try to find the "largest subset" range
  const curKey = buildPHideKey(ds, col, curMin, curMax);
  if (localStorage.getItem(curKey)) return false;

  const prefix = `${PHIDE_PREFIX}:${ds}:${col}:`;
  let best = null; // { key, min, max, obj }
  for (let i=0; i<localStorage.length; i++){
    const k = localStorage.key(i);
    if (!k || !k.startsWith(prefix)) continue;
    const tail = k.substring(prefix.length); // e.g. "1-593"
    const mm = tail.match(/^(\d+)-(\d+)$/);
    if (!mm) continue;
    const m = Number(mm[1]), M = Number(mm[2]);
    // candidate must be subset of current range
    if (m >= curMin && M <= curMax){
      let obj = null;
      try { obj = JSON.parse(localStorage.getItem(k) || 'null'); } catch(_){}
      if (!obj || typeof obj !== 'object') continue;
      const size = (M - m);
      if (!best || size > (best.max - best.min)){
        best = { key: k, min: m, max: M, obj };
      }
    }
  }
  if (!best) return false;

  // Adopt its default + overrides into current key (copy-forward)
  const merged = {
    default: !!best.obj.default,
    overrides: (best.obj.overrides && typeof best.obj.overrides === 'object')
      ? best.obj.overrides : {}
  };
  try { localStorage.setItem(curKey, JSON.stringify(merged)); } catch(_){}
  return true;
}

function loadPHide(){
  const {min, max} = currentRange();
  const ds = String(currentDatasetId());
  const col = String(currentCollectionId());
  const key = buildPHideKey(ds, col, min, max);

  let obj = null;
  try { obj = JSON.parse(localStorage.getItem(key) || 'null'); } catch(_){}
  if (!obj) {
    // Try forward-migration from a smaller range for same dataset+collection
    if (tryMigratePHideForward(ds, col, min, max)){
      try { obj = JSON.parse(localStorage.getItem(key) || 'null'); } catch(_){}
    }
  }

  if (obj && typeof obj === 'object'){
    pinyinDefaultVisible = !!obj.default;
    pinyinOverrides = new Map();
    if (obj.overrides && typeof obj.overrides === 'object'){
      for (const k in obj.overrides){
        if (!obj.overrides.hasOwnProperty(k)) continue;
        pinyinOverrides.set(k, !!obj.overrides[k]);
      }
    }
  } else {
    pinyinDefaultVisible = true;
    pinyinOverrides.clear();
  }
}

/**********************
 * Sentence helpers — robust lookup (mirrors Drift)
 **********************/
function codePointLength(str){
  try { return Array.from(str || '').length; } catch { return (str || '').length; }
}

function buildExamplePoolForChar(ch){
  // Prefer dataset SIDs via indexMap
  try {
    const postings = (window.indexMap && window.indexMap[ch]) || [];
    const sidList = Array.from(new Set((postings || []).map(v => {
      const n = typeof v === 'number' ? v : parseInt(v,10);
      return Number.isFinite(n) ? n : null;
    }).filter(n => n !== null)));
    if (sidList.length){
      return { type:'sid', items: sidList };
    }
  } catch {}

  // Try common per-char maps
  const sources = [
    (g)=> g.examplesByChar?.[ch],
    (g)=> g.sentencesByChar?.[ch],
    (g)=> g.sIndex?.[ch],
    (g)=> g.sentenceIndex?.[ch],
    (g)=> g.exIndex?.[ch],
  ];
  for (const pick of sources){
    try {
      const arr = pick(window);
      if (Array.isArray(arr) && arr.length){
        const norm = arr.map(e => (e && typeof e === 'object') ? (e.cn || e.s || e.text || '') : String(e || ''))
                        .filter(Boolean);
        if (norm.length) return { type:'plain', items:norm };
      }
    } catch {}
  }

  // Fallback to per-item fields
  try {
    const col = (typeof getActiveCollection === 'function' ? getActiveCollection() : { items:{} });
    const items = col.items || {};
    const key = (typeof itemKeyForChar === 'function' ? itemKeyForChar(ch) : ('char:'+ch));
    const it  = items[key] || {};
    const candidates = [
      it.cnSentence, it.sent, it.sentence, it.example, it.examples?.[0],
      it.ex, it.exS, it.exSentence, it.s, it.phrase, it.phr
    ].filter(Boolean).map(String);
    if (candidates.length) return { type:'plain', items: candidates };
  } catch {}

  return { type:'none', items: [] };
}

function firstSentenceForChar(ch){
  const pool = buildExamplePoolForChar(ch);
  if (!pool || !pool.items || !pool.items.length) return '';
  if (pool.type === 'sid'){
    const sid = pool.items[0];
    const s = (window.sentences && window.sentences[sid - 1]) || '';
    return (typeof s === 'string') ? s.trim() : '';
  } else {
    const s = pool.items[0];
    return (typeof s === 'string') ? s.trim() : '';
  }
}

let _mhSuppressNextSentence = false; // prevents scheduling in certain paths
let _mhLastScheduled = { ch:'', t:0 };

function maybeSpeakSentence(ch){
  try {
    const s = firstSentenceForChar(ch);
    if (!s) return;
    if (codePointLength(s) <= SENTENCE_MAX_CHARS){
      // De-dupe if a schedule just happened for the same char (e.g., double handlers)
      const now = Date.now();
      if (_mhLastScheduled.ch === ch && (now - _mhLastScheduled.t) < 400) return;
      _mhLastScheduled = { ch, t: now };

      setTimeout(()=>{
        // speaking the sentence should NOT trigger another sentence
        _mhSuppressNextSentence = true;
        try { speakNow(s); } finally {
          // allow future sentence scheduling again on the next user gesture
          setTimeout(()=>{ _mhSuppressNextSentence = false; }, 0);
        }
      }, SENTENCE_DELAY_MS);
    }
  } catch(_){}
}

/**********************
 * Open / Close
 **********************/
function openListModal(){
  // restore persisted PHide state for current selection
  loadPHide();

  // restore saved font size
  listFontPx = clampNum(Number(localStorage.getItem(LIST_FONT_KEY)) || listFontPx, LIST_FONT_MIN, LIST_FONT_MAX);

  ensureTopBar();
  if (listFontSlider) {
    listFontSlider.value = String(listFontPx);
    const v = document.getElementById('listFontVal');
    if (v) v.textContent = String(listFontPx) + 'px';
  }

  renderListModal();
  listOverlay.classList.add('open');
  listOverlay.setAttribute('aria-hidden','false');

  ensureListScrollbar();
  syncBarToContent();
  updateThumb();
  showBar();

  if (!keysWired){
    keysWired = true;
    document.addEventListener('keydown', onGlobalKeys);
  }
}

function closeListModal(){
  listOverlay.classList.remove('open');
  listOverlay.setAttribute('aria-hidden','true');
  hideBar();
  // keep persisted state; do not clear localStorage
}

if (listClose)    listClose.addEventListener('click', closeListModal);
if (listOverlay)  listOverlay.addEventListener('click', (e)=>{ if (e.target === listOverlay) closeListModal(); });
if (idleListBtn)  idleListBtn.addEventListener('click', openListModal);

function onGlobalKeys(e){
  if (e.key === 'Escape' && listOverlay?.classList.contains('open')) {
    e.preventDefault();
    closeListModal();
    return;
  }
  if (!listOverlay?.classList.contains('open')) return;
  if (e.key.toLowerCase() === 'w'){
    e.preventDefault();
    toggleSortMethod();
    renderListModal();
  }
}

/**********************
 * GLOBAL HOOKS so *any* “play char” also schedules the sentence
 * (covers card view even if it uses different speaker functions)
 **********************/
(function wrapAnyCharSpeaker(){
  const names = ['speakChar','playChar','playHanzi','pronounce','playAudioForChar'];
  names.forEach(n=>{
    const fn = window[n];
    if (typeof fn === 'function' && !fn._mhWrapped){
      function wrapped(ch){
        const res = fn.apply(this, arguments);
        try {
          if (!_mhSuppressNextSentence) maybeSpeakSentence(ch);
        } catch(_){}
        return res;
      }
      wrapped._mhWrapped = true;
      wrapped._mhOrig = fn; // reference so we can speak only-char on pinyin toggles
      window[n] = wrapped;
    }
  });
})();

// Last-resort hook: if the card ultimately speaks via Web Speech API directly.
(function hookSpeechSynthesis(){
  if (!('speechSynthesis' in window)) return;
  if (speechSynthesis._mhWrapped) return;
  const origSpeak = speechSynthesis.speak.bind(speechSynthesis);
  function isLikelySingleHanzi(t){
    const s = String(t || '');
    const len = Array.from(s).length;
    return len === 1 && /[\u3400-\u9FFF]/.test(s);
  }
  speechSynthesis.speak = function(u){
    try {
      const text = (u && typeof u.text === 'string') ? u.text : '';
      if (!_mhSuppressNextSentence && isLikelySingleHanzi(text)){
        maybeSpeakSentence(text);
      }
    } catch(_){}
    return origSpeak(u);
  };
  speechSynthesis._mhWrapped = true;
})();

/**********************
 * Sort toggle
 **********************/
function toggleSortMethod(){
  currentSortMethod = (currentSortMethod + 1) % 5; // 0..4
  try { localStorage.setItem(SORT_KEY, String(currentSortMethod)); } catch(_){}
  if (sortBtn) sortBtn.textContent = labelForSortMethod(currentSortMethod);
  applySortBtnTheme();
}

/**********************
 * Helpers
 **********************/
function clampNum(n, lo, hi){
  return Math.max(lo, Math.min(hi, Number.isFinite(n) ? n : lo));
}
function pinyinForChar(ch){
  const arr = (typeof pyIndex !== 'undefined' && pyIndex[ch]) || [];
  return arr[0]?.py || '';
}
function shortDateISO(iso){
  if (!iso || typeof iso !== 'string') return '—';
  const m = iso.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  return m ? `${m[2]}-${m[3]}` : iso;
}
function lookupInPleco(term){
  try {
    if (typeof window.openPleco === 'function') return window.openPleco(term);
  } catch(_) {}
  const q = encodeURIComponent(term || '');
  if (q) location.href = `plecoapi://x-callback-url/s?q=${q}`;
}
function speakNow(ch){
  try { if (window.speechSynthesis) speechSynthesis.cancel(); } catch(_){}
  if (typeof speakChar === 'function') return speakChar(ch);
  if ('speechSynthesis' in window){
    const u = new SpeechSynthesisUtterance(ch);
    try { speechSynthesis.speak(u); } catch(_){}
  }
}
function dueNumeric(it){
  if (!it || typeof it !== 'object') return Number.POSITIVE_INFINITY;
  if (typeof it.n === 'number') return it.n;
  if (typeof it.nT === 'number') return it.nT;
  const p = it.nP;
  if (typeof p === 'string'){
    const t = Date.parse(p);
    if (!Number.isNaN(t)) return t;
  }
  return Number.POSITIVE_INFINITY;
}
function hasSeen(it){
  return Number.isFinite(it?.PrTS);
}

/* ---- Pinyin visibility helpers ---- */
function isPinyinVisible(ch){
  return pinyinOverrides.has(ch) ? !!pinyinOverrides.get(ch) : !!pinyinDefaultVisible;
}
function setPinyinVisible(ch, vis){
  pinyinOverrides.set(ch, !!vis);
  savePHide();
}
function currentlyAllVisible(recs){
  if (!recs || !recs.length) return true;
  for (let i=0;i<recs.length;i++){
    if (!isPinyinVisible(recs[i].ch)) return false;
  }
  return true;
}
function toggleAllPinyinWithConfirm(recs){
  const allVis = currentlyAllVisible(recs);
  const nextVis = !allVis;
  const msg = nextVis
    ? 'Show Pinyin for ALL cards in this selection?\n(This will override individual hide/show states.)'
    : 'Hide Pinyin for ALL cards in this selection?\n(This will override individual hide/show states.)';
  const ok = window.confirm(msg);
  if (!ok) return;

  pinyinDefaultVisible = nextVis;
  pinyinOverrides.clear();
  savePHide();
  applyPinyinVisibility();
}

/**********************
 * Gather + sort records
 * t is ALWAYS r - w (as requested)
 **********************/
function gatherSortedRecords(){
  const listChars = (typeof chars !== 'undefined' && Array.isArray(chars)) ? chars : [];
  const col   = (typeof getActiveCollection === 'function' ? getActiveCollection() : { items:{} });
  const items = col.items || {};

  let recs = listChars.map((ch, idx)=>{
    const key = (typeof itemKeyForChar === 'function' ? itemKeyForChar(ch) : ('char:'+ch));
    const it  = items[key] || (typeof defaultItemRecord === 'function' ? defaultItemRecord() : {});
    const r = it.r ?? 0;
    const w = it.w ?? 0;
    const t = r - w;

    return {
      number: idx + 1,
      ch,
      py: pinyinForChar(ch),
      it,
      nextNum: dueNumeric(it),
      nextDisp: it?.nP ?? '—',
      level: it.level ?? 0,
      r,
      w,
      t
    };
  });

  if (currentSortMethod !== 1 && currentSortMethod !== 4){
    recs = recs.filter(rec => hasSeen(rec.it));
  }
  if (currentSortMethod === 4){
    recs = recs.filter(rec => !hasSeen(rec.it));
  }

  switch(currentSortMethod){
    case 0: recs.sort((a,b)=> a.t - b.t || a.number - b.number); break;
    case 1: recs.sort((a,b)=> a.number - b.number); break;
    case 2: recs.sort((a,b)=> a.nextNum - b.nextNum || a.number - b.number); break;
    case 3: recs.sort((a,b)=> a.level - b.level || a.number - b.number); break;
    case 4: recs.sort((a,b)=> a.number - b.number); break;
  }
  return recs;
}

/**********************
 * Render (ALL characters)
 **********************/
function renderListModal(){
  const listChars = (typeof chars !== 'undefined' && Array.isArray(chars)) ? chars : [];
  if (!listChars.length) { listContent.innerHTML = '<p>No data loaded.</p>'; return; }

  if (sortBtn) sortBtn.textContent = labelForSortMethod(currentSortMethod);
  applySortBtnTheme();

  const recs = gatherSortedRecords();

  // Build rows: Hanzi & Pinyin are separate spans (Pinyin inside a wider "pinyin-cell")
  const rows = recs.map(rec => {
    const plecoBtn = isMobileTouch
      ? `<button class="pleco-button" data-pleco="${rec.ch}" title="Open in Pleco">P</button>`
      : '';

    const shortNext = shortDateISO(rec.nextDisp);
    const r = Number(rec.r) || 0;
    const w = Number(rec.w) || 0;
    const t = r - w; // total = right - wrong
    const metaHtml =
      `<span class="stat-meta" style="margin-left:auto; display:flex; gap:.5rem; align-items:center;">
         <span class="stat-next">${shortNext}</span>
         <span class="stat-level">L${rec.level}</span>
         <span class="stat-wr" style="color:var(--text-sub); font-size:.9em;">(${t},${r},${w})</span>
       </span>`;
    const pyText = rec.py || '';
    // pinyin-cell stays clickable/touchable even when the inner text is hidden (opacity 0)
    const pyCell =
      `<span class="pinyin-cell"
              data-ch="${rec.ch}"
              role="button"
              tabindex="0"
              aria-pressed="true"
              title="Toggle Pinyin"
              style="flex:1; min-height:1.2em; padding:.1rem .3rem; cursor:pointer; user-select:none; display:flex; align-items:center;">
         <span class="stat-pinyin" data-ch="${rec.ch}">${pyText}</span>
       </span>`;

    return (
      `<div class="stat-item" data-ch="${rec.ch}" style="display:flex; align-items:center; gap:.5rem;">
         <span class="stat-index">${rec.number}.</span>
         ${plecoBtn}
         <span class="stat-word" title="Click to play">${rec.ch}</span>
         ${pyCell}
         ${metaHtml}
       </div>`
    );
  });

  listContent.innerHTML = rows.join('');

  // Delegate clicks (speak / pleco) — bind once, keep persistent
  if (!renderListModal._clickBound) {
    listContent.addEventListener('click', onListClick);
    renderListModal._clickBound = true;
  }

  // Keyboard toggle for Pinyin (Enter/Space) — bind once
  if (!renderListModal._keyBound){
    listContent.addEventListener('keydown', (e)=>{
      if (!listOverlay?.classList.contains('open')) return;
      const el = e.target.closest('.pinyin-cell, .stat-pinyin');
      if (!el) return;
      if (e.key === 'Enter' || e.key === ' ' || e.code === 'Space'){
        e.preventDefault();
        e.stopPropagation();
        const ch = el.getAttribute('data-ch') || el.querySelector('[data-ch]')?.getAttribute('data-ch') || '';
        if (ch) {
          setPinyinVisible(ch, !isPinyinVisible(ch));
          applyPinyinVisibility();
          // Speak the character after a tick (char only — no sentence) for reliability
          requestAnimationFrame(() => {
            _mhSuppressNextSentence = true;           // avoid triggering sentence via hooks
            try {
              if (window.speakChar && window.speakChar._mhOrig) {
                window.speakChar._mhOrig(ch);
              } else {
                speakNow(ch);
              }
            } finally {
              setTimeout(()=>{ _mhSuppressNextSentence = false; }, 0);
            }
          });
        }
      }
    });
    renderListModal._keyBound = true;
  }

  // Scrollbar sync — bind once
  if (!renderListModal._scrollBound){
    listContent.addEventListener('scroll', () => {
      syncBarToContent();
      updateThumb();
    }, { passive:true });
    renderListModal._scrollBound = true;
  }

  // Initial layout + on resize
  syncBarToContent();
  updateThumb();
  if (!renderListModal._resizeBound){
    window.addEventListener('resize', ()=>{ syncBarToContent(); updateThumb(); }, { passive:true });
    renderListModal._resizeBound = true;
  }

  // Apply persisted pinyin visibility + font size
  applyPinyinVisibility();
  applyListFontSize();
}

/* Apply current pinyin visibility state to DOM */
function applyPinyinVisibility(){
  const nodes = listContent.querySelectorAll('.stat-pinyin[data-ch]');
  nodes.forEach(el=>{
    const ch = el.getAttribute('data-ch') || '';
    const vis = isPinyinVisible(ch);
    // Keep layout & tap area: use opacity instead of display/visibility
    el.style.opacity = vis ? '1' : '0';
    el.style.pointerEvents = 'auto'; // ensure it always remains tappable
    el.setAttribute('aria-pressed', vis ? 'true' : 'false');
    el.setAttribute('aria-hidden', vis ? 'false' : 'true');
  });
}

/* Apply font size (Hanzi & Pinyin only) */
function applyListFontSize(){
  const hzSize = (listFontPx + 6) + 'px'; // Hanzi a bit larger
  const pySize = listFontPx + 'px';
  listContent.querySelectorAll('.stat-word').forEach(el => { el.style.fontSize = hzSize; });
  listContent.querySelectorAll('.stat-pinyin').forEach(el => { el.style.fontSize = pySize; });
}

/* Row click behavior */
function onListClick(e){
  // Handle Pleco pill
  const plecoBtn = e.target.closest('.pleco-button');
  if (plecoBtn){
    e.preventDefault(); e.stopPropagation();
    const phrase = plecoBtn.dataset.pleco || '';
    if (phrase) lookupInPleco(phrase);
    return;
  }

  // If click is inside pinyin area, don't speak/open anything (toggle handled elsewhere)
  if (e.target.closest('.pinyin-cell, .stat-pinyin')) return;

  // Handle row click -> speak Hanzi, then maybe speak sentence
  const row = e.target.closest('.stat-item');
  if (!row) return;
  const ch = row.dataset.ch;
  if (ch) {
    speakNow(ch);
    maybeSpeakSentence(ch);
  }
}

/**********************
 * Capture-phase guards & long-press handling
 * Swallow events on pinyin area so listCards doesn’t see them.
 * Support single-click toggle and long-press (with confirm) consistently on desktop & mobile.
 **********************/
function isPinyinTarget(target){
  return !!(target && target.closest && target.closest('.pinyin-cell, .stat-pinyin'));
}
function getChFromTarget(target){
  const el = target.closest('.pinyin-cell, .stat-pinyin');
  if (!el) return '';
  return el.getAttribute('data-ch') || el.querySelector('[data-ch]')?.getAttribute('data-ch') || '';
}

// Pointer path (desktop + most modern mobile)
if (!document._pinyinPointerGuardsBound){
  document.addEventListener('pointerdown', (e)=>{
    if (!listOverlay?.classList.contains('open')) return;
    if (!isPinyinTarget(e.target)) return;
    // start long-press timer
    clearTimeout(longPressTimer);
    longPressFired = false;
    longPressTimer = setTimeout(()=>{
      longPressFired = true;
      const recs = gatherSortedRecords();
      toggleAllPinyinWithConfirm(recs);
      suppressClicksUntil = Date.now() + 500; // suppress following synthetic click
    }, LONG_PRESS_MS);
  }, true); // capture

  const clearPointerTimer = ()=>{
    clearTimeout(longPressTimer);
    if (longPressFired){
      suppressClicksUntil = Date.now() + 500;
    }
  };
  document.addEventListener('pointerup', clearPointerTimer, true);
  document.addEventListener('pointercancel', clearPointerTimer, true);
  document.addEventListener('pointerleave', clearPointerTimer, true);

  // Single toggle on click (unless suppressed)
  document.addEventListener('click', (e)=>{
    if (!listOverlay?.classList.contains('open')) return;
    if (!isPinyinTarget(e.target)) return;

    // Swallow before listCards sees it
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();

    if (Date.now() < suppressClicksUntil) return; // swallowed ghost click after long-press

    // normal single toggle
    const ch = getChFromTarget(e.target);
    if (ch){
      setPinyinVisible(ch, !isPinyinVisible(ch));
      applyPinyinVisibility();
      // Speak char (only) after a tick; avoid sentence by using original if wrapped
      requestAnimationFrame(() => {
        _mhSuppressNextSentence = true;
        try {
          if (window.speakChar && window.speakChar._mhOrig) {
            window.speakChar._mhOrig(ch);
          } else {
            speakNow(ch);
          }
        } finally {
          setTimeout(()=>{ _mhSuppressNextSentence = false; }, 0);
        }
      });
    }
  }, true);

  document._pinyinPointerGuardsBound = true;
}

// Touch fallback (older Safari without PointerEvent)
if (!hasPointer && !document._pinyinTouchGuardsBound){
  let touchTimer = null;
  let touchLongFired = false;

  document.addEventListener('touchstart', (e)=>{
    if (!listOverlay?.classList.contains('open')) return;
    if (!isPinyinTarget(e.target)) return;

    touchLongFired = false;
    clearTimeout(touchTimer);
    touchTimer = setTimeout(()=>{
      touchLongFired = true;
      const recs = gatherSortedRecords();
      toggleAllPinyinWithConfirm(recs);
      suppressClicksUntil = Date.now() + 700; // a bit longer for iOS ghost click
    }, LONG_PRESS_MS);
  }, true);

  const endTouch = ()=>{
    clearTimeout(touchTimer);
    if (touchLongFired){
      suppressClicksUntil = Date.now() + 700;
    }
  };
  document.addEventListener('touchend', endTouch, true);
  document.addEventListener('touchcancel', endTouch, true);

  // Click guard as well (older iOS still fires click)
  document.addEventListener('click', (e)=>{
    if (!listOverlay?.classList.contains('open')) return;
    if (!isPinyinTarget(e.target)) return;

    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();

    if (Date.now() < suppressClicksUntil) return;

    const ch = getChFromTarget(e.target);
    if (ch){
      setPinyinVisible(ch, !isPinyinVisible(ch));
      applyPinyinVisibility();
      // Speak char (only) after a tick; avoid sentence by using original if wrapped
      requestAnimationFrame(() => {
        _mhSuppressNextSentence = true;
        try {
          if (window.speakChar && window.speakChar._mhOrig) {
            window.speakChar._mhOrig(ch);
          } else {
            speakNow(ch);
          }
        } finally {
          setTimeout(()=>{ _mhSuppressNextSentence = false; }, 0);
        }
      });
    }
  }, true);

  document._pinyinTouchGuardsBound = true;
}

/**********************
 * Custom scrollbar (controls #listContent)
 **********************/
function syncBarToContent(){
  const bar = getBar();
  if (!bar || !listContent) return;
  const r = listContent.getBoundingClientRect();
  bar.style.top    = `${Math.round(r.top)}px`;
  bar.style.left   = `${Math.round(r.right - 28)}px`;
  bar.style.height = `${Math.round(r.height)}px`;
}
function updateThumb(){
  const bar = getBar(), thumb = getThumb();
  if (!bar || !thumb || !listContent) return;

  const viewport = listContent.clientHeight;
  const contentH = listContent.scrollHeight;

  if (contentH <= viewport){ hideBar(); return; }
  showBar();

  const trackH = bar.clientHeight;
  const th = Math.max(30, Math.round((viewport / contentH) * trackH));
  thumb.style.height = `${th}px`;

  const maxTop = Math.max(0, trackH - th);
  const ratio  = listContent.scrollTop / Math.max(1, (contentH - viewport));
  thumb.style.top = `${Math.round(ratio * maxTop)}px`;
}

/* Drag thumb to scroll content */
(function wireThumbDrag(){
  let dragging = false, startY = 0, startTop = 0;
  document.addEventListener('pointerdown', e=>{
    const thumb = getThumb();
    if (!thumb || e.target !== thumb) return;
    dragging = true;
    startY   = e.clientY;
    startTop = parseFloat(getComputedStyle(thumb).top) || 0;
    thumb.setPointerCapture(e.pointerId);
    e.preventDefault();
  });
  document.addEventListener('pointermove', e=>{
    if (!dragging) return;
    const bar = getBar(), thumb = getThumb();
    if (!bar || !thumb || !listContent) return;

    const trackH = bar.clientHeight;
    const th     = thumb.clientHeight;
    const maxTop = Math.max(0, trackH - th);

    let newTop = startTop + (e.clientY - startY);
    newTop = Math.max(0, Math.min(maxTop, newTop));
    thumb.style.top = `${Math.round(newTop)}px`;

    const ratio = maxTop ? (newTop / maxTop) : 0;
    listContent.scrollTop = ratio * (listContent.scrollHeight - listContent.clientHeight);
  });
  document.addEventListener('pointerup', ()=> dragging = false);
  document.addEventListener('pointercancel', ()=> dragging = false);
})();

// Expose for Drift <-> List handshake
window.openListModal  = openListModal;
window.closeListModal = closeListModal;

/**********************
 * Centered “Hanzi Drift” CTA wiring (uses your HTML #listDriftCTA)
 * - closes List first
 * - sets _mhReopenListAfterDrift so Drift can bring List back on exit
 * - lazy-loads hanziDrift.js if not present
 **********************/
(function wireListDriftCTA(){
  const btn = document.getElementById('listDriftCTA');
  if (!btn) return;

  btn.addEventListener('click', () => {
    window._mhReopenListAfterDrift = true;
    try { closeListModal(); } catch {}

    const openDriftNow = () => {
      if (typeof window.mhOpenDriftEntry === 'function') {
        window.mhOpenDriftEntry();
      }
    };

    if (typeof window.mhOpenDriftEntry === 'function') {
      // Already loaded
      openDriftNow();
      return;
    }

    // Optional lazy-load if not present
    const src = window.HANZI_DRIFT_SRC || 'HunterBubbles.js';
    let s = document.querySelector('script[data-hanzi-drift]');
    if (!s) {
      s = document.createElement('script');
      s.src = src;
      s.async = false;
      s.dataset.hanziDrift = '1';
      s.addEventListener('load', openDriftNow, { once: true });
      s.addEventListener('error', () => {
        window._mhReopenListAfterDrift = false;
        alert('Could not load ' + src);
      }, { once: true });
      document.body.appendChild(s);
    } else {
      s.addEventListener('load', openDriftNow, { once: true });
      if (s.dataset.loaded === '1') openDriftNow();
    }
  });
})();
